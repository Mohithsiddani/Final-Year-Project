"""
Test script to verify MongoDB connectivity and setup
Run this before running the main application
"""
import os
import sys

def test_mongodb_connection():
    """Test MongoDB connection with the provided URI."""
    
    print("\n" + "="*60)
    print("MongoDB Connection Test")
    print("="*60 + "\n")
    
    # Get connection string from environment or ask user
    mongodb_uri = os.getenv("MONGODB_URI")
    
    if not mongodb_uri:
        print("⚠️  MONGODB_URI environment variable not set")
        print("\nPlease provide your MongoDB connection string:")
        mongodb_uri = input("> ").strip()
        
        if not mongodb_uri:
            print("❌ No connection string provided")
            return False
    
    print(f"📋 Connection String (masked):")
    # Mask password for security
    masked = mongodb_uri.replace(mongodb_uri.split("@")[0].split("://")[1], "username:***")
    print(f"   {masked}\n")
    
    # Test pymongo installation
    print("1️⃣  Checking pymongo installation...")
    try:
        import pymongo
        print(f"   ✓ pymongo {pymongo.__version__} installed\n")
    except ImportError:
        print("   ❌ pymongo not installed")
        print("   Install with: pip install pymongo\n")
        return False
    
    # Test connection
    print("2️⃣  Testing MongoDB connection...")
    try:
        from pymongo import MongoClient
        client = MongoClient(mongodb_uri, serverSelectionTimeoutMS=5000)
        client.admin.command('ping')
        print("   ✓ Connected to MongoDB\n")
    except Exception as e:
        print(f"   ❌ Connection failed: {e}\n")
        print("   Troubleshooting:")
        print("   - Verify connection string is correct")
        print("   - Check MongoDB Atlas cluster is running")
        print("   - Whitelist your IP in MongoDB Atlas Network Access\n")
        return False
    
    # Test database access
    print("3️⃣  Testing database access...")
    try:
        db_name = mongodb_uri.split("@")[-1].split("/")[1].split("?")[0] if "/" in mongodb_uri.split("@")[-1] else "quantum_guard"
        db = client[db_name]
        
        # Try to list collections
        collections = db.list_collection_names()
        print(f"   ✓ Database: {db_name}")
        print(f"   ✓ Collections: {collections if collections else 'none (will be created on first use)'}\n")
    except Exception as e:
        print(f"   ❌ Database access failed: {e}\n")
        return False
    
    # Test database factory
    print("4️⃣  Testing database factory...")
    try:
        # Set environment variable for factory
        os.environ["DB_TYPE"] = "mongodb"
        os.environ["MONGODB_URI"] = mongodb_uri
        
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from database_factory import get_database
        
        db_instance = get_database()
        print("   ✓ Database factory initialized\n")
    except Exception as e:
        print(f"   ❌ Factory initialization failed: {e}\n")
        return False
    
    # Success!
    print("="*60)
    print("✅ All tests passed! MongoDB is ready to use.")
    print("="*60)
    print("\nYou can now start the backend:")
    print("  python main.py")
    print("\nTo use MongoDB, ensure these environment variables are set:")
    print("  DB_TYPE=mongodb")
    print("  MONGODB_URI=<your_connection_string>")
    print()
    
    return True


def test_csv_setup():
    """Test CSV storage setup."""
    print("\n" + "="*60)
    print("CSV Storage Test")
    print("="*60 + "\n")
    
    print("1️⃣  Checking CSV files...")
    import os
    csv_files = {
        "records.csv": os.path.exists("records.csv"),
        "tamper_logs.csv": os.path.exists("tamper_logs.csv"),
        "notifications.csv": os.path.exists("notifications.csv")
    }
    
    for filename, exists in csv_files.items():
        status = "✓ exists" if exists else "⚠️  will be created on first use"
        print(f"   {filename}: {status}")
    
    print("\n2️⃣  Testing database factory with CSV...")
    try:
        # Ensure CSV mode
        os.environ["DB_TYPE"] = "csv"
        if "MONGODB_URI" in os.environ:
            del os.environ["MONGODB_URI"]
        
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from database_factory import get_database
        
        db_instance = get_database()
        print("   ✓ CSV database initialized\n")
    except Exception as e:
        print(f"   ❌ CSV initialization failed: {e}\n")
        return False
    
    print("="*60)
    print("✅ CSV storage is ready!")
    print("="*60)
    print("\nYou can start the backend:")
    print("  python main.py")
    print()
    
    return True


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Test database connectivity")
    parser.add_argument("--mongodb", action="store_true", help="Test MongoDB connection")
    parser.add_argument("--csv", action="store_true", help="Test CSV storage")
    parser.add_argument("--all", action="store_true", help="Test both setups")
    parser.add_argument("--uri", type=str, help="MongoDB connection string to test")
    
    args = parser.parse_args()
    
    # If URI provided, set it in environment
    if args.uri:
        os.environ["MONGODB_URI"] = args.uri
    
    # Default to testing based on DB_TYPE if no args provided
    if not args.mongodb and not args.csv and not args.all:
        db_type = os.getenv("DB_TYPE", "csv").lower()
        args.all = True  # Test both
    
    success = True
    
    if args.mongodb or args.all:
        result = test_mongodb_connection()
        if not result and not args.all:
            success = False
    
    if args.csv or args.all:
        result = test_csv_setup()
        if not result and not args.all:
            success = False
    
    sys.exit(0 if success else 1)
