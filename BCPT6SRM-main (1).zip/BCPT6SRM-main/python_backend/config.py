# Database Configuration
# Set the database type: 'csv' or 'mongodb'
DB_TYPE = "csv"  # Change to "mongodb" to use MongoDB

# MongoDB Connection String (provide when switching to MongoDB)
# Example: "mongodb+srv://username:password@cluster.mongodb.net/quantum_guard?retryWrites=true&w=majority"
MONGODB_URI = None

# CSV file paths (used when DB_TYPE is "csv")
CSV_RECORDS_PATH = "records.csv"
CSV_LOGS_PATH = "tamper_logs.csv"
CSV_NOTIFICATIONS_PATH = "notifications.csv"

# Application settings
QUANTUM_HASH_QUBITS = 8
SESSION_TIMEOUT_MINUTES = 60
