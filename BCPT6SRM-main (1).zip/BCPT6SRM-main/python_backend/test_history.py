import urllib.request
import urllib.error
import json
import time

BASE_URL = "http://localhost:8002"

def make_request(method, endpoint, data=None, headers=None):
    if headers is None:
        headers = {}
    
    url = f"{BASE_URL}{endpoint}"
    req = urllib.request.Request(url, method=method)
    
    for k, v in headers.items():
        req.add_header(k, v)
    
    req.add_header("Content-Type", "application/json")
    
    body = None
    if data is not None:
        body = json.dumps(data).encode('utf-8')
    
    try:
        with urllib.request.urlopen(req, data=body) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8')
    except Exception as e:
        return 0, str(e)

def test_history():
    # Wait for server to start
    print("Waiting for server to start...")
    for i in range(10):
        try:
            with urllib.request.urlopen(BASE_URL) as response:
                if response.status == 200:
                    break
        except:
            time.sleep(1)
            print(".", end="", flush=True)
    print("\nServer reachable.")

    # 1. Login
    print("1. Logging in...")
    status, resp = make_request("POST", "/auth/login", {"username": "admin", "password": "admin123"})
    if status != 200:
        print(f"Login failed: {resp}")
        return
    token = resp["token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("Login successful.")

    # 2. Get Records
    print("2. Fetching records...")
    status, records = make_request("GET", "/records", headers=headers)
    if status != 200:
        print(f"Get records failed: {records}")
        return
    
    record_id = None
    if not records:
        print("No records found. Creating one...")
        # Add record
        new_rec = {
            "personal": {
                "patientId": "P-123",
                "patientName": "Test Pat",
                "age": 30,
                "gender": "Male",
                "contactNumber": "123",
                "address": "123 St"
            },
            "medical": {
                "diagnosis": "Flu",
                "doctorName": "Dr. House",
                "symptoms": "Cough",
                "treatmentPlan": "Rest",
                "medications": "None"
            },
            "billing": {
                "totalAmount": 100,
                "insuranceProvider": "InsureCo",
                "paymentStatus": "Paid",
                "billingDate": "2023-01-01"
            }
        }
        status, resp = make_request("POST", "/records", new_rec, headers=headers)
        if status == 200:
             record_id = resp["id"]
             print(f"Created record: {record_id}")
        else:
             print(f"Failed to create record: {resp}")
             return
    else:
        # Check if records is a list
        if isinstance(records, list):
             target_record = records[0]
             record_id = target_record["id"]
        else:
             print(f"Unexpected records format: {records}")
             return

    print(f"Target Record: {record_id}")

    # 3. Simulate Tamper
    print("3. Simulating tamper...")
    update_data = {
        "field": "diagnosis",
        "newValue": "Test Tamper Value 8001",
        "userRole": "admin"
    }
    status, resp = make_request("PUT", f"/simulate_tamper/{record_id}", update_data, headers=headers)
    if status != 200:
        print(f"Simulate tamper failed: {resp}")
    else:
        print("Tamper simulated successfully.")

    # 4. Get History
    print("4. Fetching history...")
    status, history = make_request("GET", f"/records/{record_id}/history", headers=headers)
    if status != 200:
        print(f"Get history failed: {history}")
        return
    
    print("History fetched successfully.")
    
    versions = history.get("versions", [])
    if versions:
        print(f"Found {len(versions)} versions.")
        print("Latest version notes:", versions[-1].get("notes"))
    else:
        print("WARNING: No versions found in history!")

if __name__ == "__main__":
    test_history()
