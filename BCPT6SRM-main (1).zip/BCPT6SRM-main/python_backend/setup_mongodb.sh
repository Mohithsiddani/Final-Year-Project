#!/bin/bash
# Quick setup script for MongoDB integration (Linux/Mac)
# Usage: bash setup_mongodb.sh "mongodb+srv://user:pass@cluster.mongodb.net/dbname"

if [ -z "$1" ]; then
    echo ""
    echo "MongoDB Setup Script"
    echo "===================="
    echo ""
    echo "Usage: bash setup_mongodb.sh \"YOUR_MONGODB_URI\""
    echo ""
    echo "Example:"
    echo "bash setup_mongodb.sh \"mongodb+srv://username:password@cluster0.abc123.mongodb.net/quantum_guard?retryWrites=true&w=majority\""
    echo ""
    echo "Steps:"
    echo "1. Get MongoDB Atlas connection string from: https://www.mongodb.com/cloud/atlas"
    echo "2. Run this script with your connection string"
    echo "3. The environment variables will be set in your .bashrc or .zshrc"
    echo ""
    exit 1
fi

# Detect shell and appropriate config file
if [ "$SHELL" = "/bin/zsh" ] || [ "$SHELL" = "/usr/bin/zsh" ]; then
    CONFIG_FILE="$HOME/.zshrc"
    SHELL_NAME="zsh"
else
    CONFIG_FILE="$HOME/.bashrc"
    SHELL_NAME="bash"
fi

echo "Setting environment variables in $CONFIG_FILE..."

# Remove old entries if they exist
sed -i.bak '/^export DB_TYPE=/d' "$CONFIG_FILE"
sed -i.bak '/^export MONGODB_URI=/d' "$CONFIG_FILE"

# Add new entries
echo 'export DB_TYPE="mongodb"' >> "$CONFIG_FILE"
echo "export MONGODB_URI=\"$1\"" >> "$CONFIG_FILE"

echo ""
echo "✓ Environment variables set in $CONFIG_FILE:"
echo "  DB_TYPE = mongodb"
echo "  MONGODB_URI = $1"
echo ""
echo "Run: source $CONFIG_FILE"
echo "To apply changes immediately, or restart your terminal."
echo ""
