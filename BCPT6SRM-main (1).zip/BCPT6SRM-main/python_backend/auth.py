from typing import Optional
from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import secrets
from datetime import datetime, timedelta

# Simple in-memory session store (use database in production)
sessions = {}

# User database (in production, use proper database with hashed passwords)
users_db = {
    "admin": {"password": "admin123", "role": "admin", "username": "admin"},
    "user1": {"password": "user123", "role": "user", "username": "user1"},
    "user2": {"password": "user123", "role": "user", "username": "user2"},
}

security = HTTPBearer()

def create_session(username: str) -> str:
    """Create a session token for user."""
    token = secrets.token_urlsafe(32)
    sessions[token] = {
        "username": username,
        "role": users_db[username]["role"],
        "created_at": datetime.now()
    }
    return token

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from session token."""
    token = credentials.credentials
    if token not in sessions:
        raise HTTPException(status_code=401, detail="Invalid session")
    return sessions[token]

def require_admin(current_user: dict = Depends(get_current_user)):
    """Require admin role."""
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user
