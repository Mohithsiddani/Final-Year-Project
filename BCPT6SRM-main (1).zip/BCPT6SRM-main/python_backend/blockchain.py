import hashlib
import json
from datetime import datetime
import sys
import os
import pandas as pd

# Handle both relative and absolute imports
try:
    from .quantum_engine import QuantumHashEngine
except ImportError:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from quantum_engine import QuantumHashEngine

class Blockchain:
    def __init__(self, database):
        self.db = database
        self.quantum_engine = QuantumHashEngine()

    def create_block_data(self, record_data):
        """
        Prepares a record with hashes and blockchain metadata.
        """
        # Create a string representation of the three data sections
        data_to_hash = json.dumps({
            "personal": {
                "patientId": record_data.get("patientId"),
                "patientName": record_data.get("patientName"),
                "age": record_data.get("age"),
                "gender": record_data.get("gender"),
                "contactNumber": record_data.get("contactNumber"),
                "address": record_data.get("address"),
            },
            "medical": {
                "diagnosis": record_data.get("diagnosis"),
                "doctorName": record_data.get("doctorName"),
                "symptoms": record_data.get("symptoms"),
                "treatmentPlan": record_data.get("treatmentPlan"),
                "medications": record_data.get("medications"),
            },
            "billing": {
                "totalAmount": record_data.get("totalAmount"),
                "insuranceProvider": record_data.get("insuranceProvider"),
                "paymentStatus": record_data.get("paymentStatus"),
                "billingDate": record_data.get("billingDate"),
            }
        }, sort_keys=True)

        # Generate hashes
        sha256_hash = hashlib.sha256(data_to_hash.encode()).hexdigest()
        quantum_hash = self.quantum_engine.generate_hash(data_to_hash)

        # Get previous block info
        records = self.db.get_all_records()
        if not records:
            previous_hash = "genesis-0000"
            index = 1
        else:
            previous_hash = records[-1]["sha256Hash"]
            index = records[-1]["blockIndex"] + 1

        block_record = {
            **record_data,
            "sha256Hash": sha256_hash,
            "quantumHash": quantum_hash,
            "timestamp": datetime.now().isoformat(),
            "blockIndex": index,
            "previousHash": previous_hash
        }
        return block_record

    def compute_hashes(self, record_data):
        """Compute deterministic SHA-256 and quantum hashes for a given record_data snapshot.
        This is used for computing hashes for version proposals without assigning block metadata.
        Returns (sha256_hash, quantum_hash).
        """
        data_to_hash = json.dumps({
            "personal": {
                "patientId": record_data.get("patientId"),
                "patientName": record_data.get("patientName"),
                "age": record_data.get("age"),
                "gender": record_data.get("gender"),
                "contactNumber": record_data.get("contactNumber"),
                "address": record_data.get("address"),
            },
            "medical": {
                "diagnosis": record_data.get("diagnosis"),
                "doctorName": record_data.get("doctorName"),
                "symptoms": record_data.get("symptoms"),
                "treatmentPlan": record_data.get("treatmentPlan"),
                "medications": record_data.get("medications"),
            },
            "billing": {
                "totalAmount": record_data.get("totalAmount"),
                "insuranceProvider": record_data.get("insuranceProvider"),
                "paymentStatus": record_data.get("paymentStatus"),
                "billingDate": record_data.get("billingDate"),
            }
        }, sort_keys=True)

        sha256_hash = hashlib.sha256(data_to_hash.encode()).hexdigest()
        quantum_hash = self.quantum_engine.generate_hash(data_to_hash)
        return sha256_hash, quantum_hash

    def verify_single_record(self, record_id):
        """
        Verifies a single record's integrity.
        Returns dictionary with verification details.
        """
        records = self.db.get_all_records()
        record_index = next((i for i, r in enumerate(records) if r["id"] == record_id), -1)
        
        if record_index == -1:
            return {"isValid": False, "error": "Record not found"}
            
        record = records[record_index]
        
        # Recompute data hash - MUST match validate_chain logic
        data_to_hash = json.dumps({
            "personal": {
                "patientId": str(record.get("patientId")) if record.get("patientId") is not None else "",
                "patientName": str(record.get("patientName")) if record.get("patientName") is not None else "",
                "age": int(float(record.get("age"))) if record.get("age") is not None else 0,
                "gender": str(record.get("gender")) if record.get("gender") is not None else "",
                "contactNumber": str(record.get("contactNumber")) if record.get("contactNumber") is not None else "",
                "address": str(record.get("address")) if record.get("address") is not None else "",
            },
            "medical": {
                "diagnosis": str(record.get("diagnosis")) if record.get("diagnosis") is not None else "",
                "doctorName": str(record.get("doctorName")) if record.get("doctorName") is not None else "",
                "symptoms": str(record.get("symptoms")) if record.get("symptoms") is not None else "",
                "treatmentPlan": str(record.get("treatmentPlan")) if record.get("treatmentPlan") is not None else "",
                "medications": str(record.get("medications")) if record.get("medications") is not None else "",
            },
            "billing": {
                "totalAmount": float(record.get("totalAmount")) if record.get("totalAmount") is not None else 0.0,
                "insuranceProvider": str(record.get("insuranceProvider")) if record.get("insuranceProvider") is not None else "",
                "paymentStatus": str(record.get("paymentStatus")) if record.get("paymentStatus") is not None else "",
                "billingDate": str(record.get("billingDate")) if record.get("billingDate") is not None else "",
            }
        }, sort_keys=True)
        
        computed_sha256 = hashlib.sha256(data_to_hash.encode()).hexdigest()
        computed_quantum = self.quantum_engine.generate_hash(data_to_hash)
        
        sha256_valid = record["sha256Hash"] == computed_sha256
        quantum_valid = record["quantumHash"] == computed_quantum
        
        previous_hash_valid = True
        if record_index > 0:
            previous_hash_valid = record["previousHash"] == records[record_index-1]["sha256Hash"]
            
        is_valid = sha256_valid and quantum_valid and previous_hash_valid
        
        return {
            "isValid": is_valid,
            "sha256Valid": sha256_valid,
            "quantumValid": quantum_valid,
            "previousHashValid": previous_hash_valid,
            "currentSHA256": computed_sha256,
            "currentQuantumHash": computed_quantum,
            "storedSHA256": record["sha256Hash"],
            "storedQuantumHash": record["quantumHash"]
        }

    def validate_chain(self, current_user=None):
        """
        Validates the entire blockchain integrity.
        Returns a list of invalid block IDs.
        current_user: dict with 'username' and 'role' keys (optional)
        """
        records = self.db.get_all_records()
        invalid_blocks = []
        
        for i in range(len(records)):
            record = records[i]
            
            # Recompute data hash
            # Recompute data hash - MUST match create_block_data structure exactly
            # Use str() to force string type (pandas infers int for "1") and 'or ""' for nulls
            # Helper function to safely get values and handle NaN
            def safe_get(record, key, default=""):
                """Safely get a value from record, handling None and NaN."""
                val = record.get(key)
                if val is None:
                    return default
                try:
                    if pd.isna(val):
                        return default
                except (TypeError, ValueError):
                    pass
                return val
            
            def safe_int(val, default=0):
                """Safely convert to int, handling None and NaN."""
                if val is None:
                    return default
                try:
                    if pd.isna(val):
                        return default
                    return int(float(val))
                except (TypeError, ValueError):
                    return default
            
            def safe_float(val, default=0.0):
                """Safely convert to float, handling None and NaN."""
                if val is None:
                    return default
                try:
                    if pd.isna(val):
                        return default
                    return float(val)
                except (TypeError, ValueError):
                    return default
            
            data_to_hash = json.dumps({
                "personal": {
                    "patientId": str(safe_get(record, "patientId", "")),
                    "patientName": str(safe_get(record, "patientName", "")),
                    "age": safe_int(safe_get(record, "age"), 0),
                    "gender": str(safe_get(record, "gender", "")),
                    "contactNumber": str(safe_get(record, "contactNumber", "")),
                    "address": str(safe_get(record, "address", "")),
                },
                "medical": {
                    "diagnosis": str(safe_get(record, "diagnosis", "")),
                    "doctorName": str(safe_get(record, "doctorName", "")),
                    "symptoms": str(safe_get(record, "symptoms", "")),
                    "treatmentPlan": str(safe_get(record, "treatmentPlan", "")),
                    "medications": str(safe_get(record, "medications", "")),
                },
                "billing": {
                    "totalAmount": safe_float(safe_get(record, "totalAmount"), 0.0),
                    "insuranceProvider": str(safe_get(record, "insuranceProvider", "")),
                    "paymentStatus": str(safe_get(record, "paymentStatus", "")),
                    "billingDate": str(safe_get(record, "billingDate", "")),
                }
            }, sort_keys=True)
            
            # Debugging: Print hash comparison if mismatch
            expected_sha256 = hashlib.sha256(data_to_hash.encode()).hexdigest()
            if record["sha256Hash"] != expected_sha256:
                print(f"Hash Mismatch for {record.get('id')}:")
                print(f"  Stored:   {record['sha256Hash']}")
                print(f"  Computed: {expected_sha256}")
                print(f"  Data:     {data_to_hash}")
            # Quantum hash might be deterministic based on engine implementation
            expected_quantum = self.quantum_engine.generate_hash(data_to_hash)

            # Check integrity
            is_valid = True
            if record["sha256Hash"] != expected_sha256:
                is_valid = False
            if record["quantumHash"] != expected_quantum:
                is_valid = False
            if i > 0 and record["previousHash"] != records[i-1]["sha256Hash"]:
                is_valid = False
            
            if not is_valid:
                invalid_blocks.append(record["id"])
                # Log the tamper event to CSV
                details = []
                if record["sha256Hash"] != expected_sha256:
                    details.append(f"Hash Mismatch. Stored: {record['sha256Hash'][:10]}... Computed: {expected_sha256[:10]}...")
                if record["quantumHash"] != expected_quantum:
                    details.append("Quantum Hash Mismatch")
                if i > 0 and record["previousHash"] != records[i-1]["sha256Hash"]:
                    details.append(f"Chain Broken. Previous Hash Mismatch")
                # Create a pending version entry for admin review (store current/tampered snapshot)
                try:
                    version_entry = {
                        "versionId": f"VER-{datetime.now().timestamp()}",
                        "dataSnapshot": record,
                        "sha256Hash": expected_sha256,
                        "quantumHash": expected_quantum,
                        "createdBy": current_user.get("username", "system") if current_user else "system",
                        "createdByRole": current_user.get("role", "system") if current_user else "system",
                        "createdAt": datetime.now().isoformat(),
                        "status": "pending",
                        "notes": "; ".join(details)
                    }
                    self.db.add_version(record["id"], version_entry)
                except Exception:
                    # If version creation fails, continue to at least log the tamper
                    pass

                self.db.log_tamper_event({
                    "recordId": record["id"],
                    "previousHash": record["previousHash"],
                    "newHash": expected_sha256,
                    "details": "; ".join(details),
                    "userId": current_user.get("username", "system") if current_user else "system",
                    "userRole": current_user.get("role", "system") if current_user else "system"
                })
                
        return invalid_blocks
