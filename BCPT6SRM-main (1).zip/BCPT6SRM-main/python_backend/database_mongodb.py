from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError, ConnectionFailure
from datetime import datetime
import json
import math
import os

class Database:
    def __init__(self, mongodb_uri=None):
        """
        Initialize MongoDB connection.
        
        Args:
            mongodb_uri: MongoDB connection string. 
                        If None, uses MONGODB_URI environment variable.
                        Example: mongodb+srv://username:password@cluster.mongodb.net/dbname?retryWrites=true&w=majority
        """
        if mongodb_uri is None:
            mongodb_uri = os.getenv("MONGODB_URI")
            if mongodb_uri is None:
                raise ValueError("MONGODB_URI not provided and MONGODB_URI environment variable not set")
        
        self.mongodb_uri = mongodb_uri
        self.client = None
        self.db = None
        self.records_collection = None
        self.logs_collection = None
        self.notifications_collection = None
        
        self._connect()
    
    def _connect(self):
        """Connect to MongoDB and initialize collections."""
        try:
            self.client = MongoClient(self.mongodb_uri, serverSelectionTimeoutMS=5000)
            # Verify connection
            self.client.admin.command('ping')
            print("✓ Connected to MongoDB")
        except (ServerSelectionTimeoutError, ConnectionFailure) as e:
            raise ConnectionError(f"Failed to connect to MongoDB: {e}")
        
        # Get database name from URI or use default
        db_name = self._extract_db_name() or "quantum_guard"
        self.db = self.client[db_name]
        
        # Initialize collections
        self.records_collection = self.db["records"]
        self.logs_collection = self.db["tamper_logs"]
        self.notifications_collection = self.db["notifications"]
        self.versions_collection = self.db["record_versions"]
        
        # Create indexes for better performance
        self._create_indexes()
    
    def _extract_db_name(self):
        """Extract database name from MongoDB URI."""
        try:
            # Format: mongodb+srv://user:pass@host/dbname?...
            if "/" in self.mongodb_uri.split("@")[-1]:
                db_part = self.mongodb_uri.split("@")[-1].split("/")[1]
                return db_part.split("?")[0] if "?" in db_part else db_part
        except (IndexError, AttributeError):
            pass
        return None
    
    def _create_indexes(self):
        """Create indexes for frequently queried fields."""
        try:
            self.records_collection.create_index("id", unique=True)
            self.records_collection.create_index("patientId")
            self.records_collection.create_index("timestamp")
            
            self.logs_collection.create_index("id", unique=True)
            self.logs_collection.create_index("recordId")
            self.logs_collection.create_index("timestamp")
            
            self.notifications_collection.create_index("id", unique=True)
            self.notifications_collection.create_index("recordId")
            self.notifications_collection.create_index("read")
            
            print("✓ Indexes created")
        except Exception as e:
            print(f"Warning: Could not create indexes: {e}")
    
    def get_all_records(self):
        """Retrieve all records from MongoDB."""
        try:
            records = list(self.records_collection.find({}, {"_id": 0}))
            return records
        except Exception as e:
            print(f"Error retrieving records: {e}")
            return []
    
    def add_record(self, record_data):
        """Add a new record to MongoDB."""
        try:
            # Ensure _id is not in the document (using custom id field instead)
            record_to_insert = {k: v for k, v in record_data.items() if k != "_id"}
            
            self.records_collection.insert_one(record_to_insert)
            return record_to_insert
        except Exception as e:
            print(f"Error adding record: {e}")
            raise
    
    def update_record_raw(self, record_id, updated_data):
        """Update a record directly."""
        try:
            result = self.records_collection.update_one(
                {"id": record_id},
                {"$set": updated_data}
            )
            return result.matched_count > 0
        except Exception as e:
            print(f"Error updating record: {e}")
            return False
    
    def add_log(self, log_data):
        """Add a tamper log entry."""
        try:
            log_to_insert = {k: v for k, v in log_data.items() if k != "_id"}
            self.logs_collection.insert_one(log_to_insert)
            return log_to_insert
        except Exception as e:
            print(f"Error adding log: {e}")
            raise
    
    def get_all_logs(self):
        """Retrieve all tamper logs."""
        try:
            # Filter out invalid entries
            logs = list(self.logs_collection.find({}, {"_id": 0}))
            
            # Clean invalid float values
            cleaned_logs = []
            for log in logs:
                cleaned_log = self._clean_record(log)
                if cleaned_log.get("id") and cleaned_log.get("recordId"):
                    cleaned_logs.append(cleaned_log)
            
            return cleaned_logs
        except Exception as e:
            print(f"Error retrieving logs: {e}")
            return []
    
    def log_tamper_event(self, event_data):
        """Log a tamper detection event."""
        try:
            log_entry = {
                "id": f"LOG-{datetime.now().timestamp()}",
                "recordId": event_data.get("recordId"),
                "previousHash": event_data.get("previousHash"),
                "newHash": event_data.get("newHash"),
                "detectedAt": datetime.now().isoformat(),
                "details": event_data.get("details"),
                "userId": event_data.get("userId", "system"),
                "userRole": event_data.get("userRole", "system"),
                "read": False
            }
            
            # Deduplication: Check if the last log for this record is the same
            last_log = self.logs_collection.find_one(
                {"recordId": event_data.get("recordId")},
                sort=[("timestamp", -1)]
            )
            
            if last_log:
                if (last_log.get("newHash") == event_data.get("newHash") and 
                    last_log.get("previousHash") == event_data.get("previousHash")):
                    # Same error already logged, skip to avoid spam
                    return None
            
            self.logs_collection.insert_one(log_entry)
            
            # Create notification for admins
            self.create_notification({
                "recordId": event_data.get("recordId"),
                "userId": event_data.get("userId", "system"),
                "userRole": event_data.get("userRole", "system"),
                "detectedAt": datetime.now().isoformat(),
                "details": event_data.get("details", f"Tamper detected in record {event_data.get('recordId', 'unknown')}")
            })
            
            return log_entry
        except Exception as e:
            print(f"Error logging tamper event: {e}")
            raise
    
    def create_notification(self, notification_data):
        """Create a new notification."""
        try:
            notification_entry = {
                "id": f"NOTIF-{datetime.now().timestamp()}",
                "recordId": notification_data.get("recordId"),
                "userId": notification_data.get("userId", "system"),
                "userRole": notification_data.get("userRole", "system"),
                "detectedAt": notification_data.get("detectedAt", datetime.now().isoformat()),
                "details": notification_data.get("details", ""),
                "read": False,
                "createdAt": datetime.now().isoformat()
            }
            
            self.notifications_collection.insert_one(notification_entry)
            return notification_entry
        except Exception as e:
            print(f"Error creating notification: {e}")
            raise
    
    def get_all_notifications(self):
        """Retrieve all notifications."""
        try:
            notifications = list(self.notifications_collection.find({}, {"_id": 0}))
            
            # Clean invalid float values
            cleaned_notifications = []
            for notif in notifications:
                cleaned_notif = self._clean_record(notif)
                cleaned_notifications.append(cleaned_notif)
            
            return cleaned_notifications
        except Exception as e:
            print(f"Error retrieving notifications: {e}")
            return []
    
    def mark_notification_read(self, notification_id):
        """Mark a notification as read."""
        try:
            result = self.notifications_collection.update_one(
                {"id": notification_id},
                {"$set": {"read": True}}
            )
            return result.matched_count > 0
        except Exception as e:
            print(f"Error marking notification as read: {e}")
            return False
    
    def _clean_record(self, record):
        """Clean a record to be JSON-compliant."""
        cleaned = {}
        for key, value in record.items():
            if key == "_id":
                continue
            cleaned[key] = self._clean_value(value)
        return cleaned
    
    def _clean_value(self, value):
        """Clean a value to be JSON-compliant."""
        if value is None:
            return None
        
        # Handle float NaN and infinity
        if isinstance(value, float):
            if math.isnan(value) or math.isinf(value):
                return None
            return value
        
        # Handle empty strings
        if isinstance(value, str) and value.strip() == '':
            return None
        
        # Handle dict/list recursively
        if isinstance(value, dict):
            return {k: self._clean_value(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._clean_value(v) for v in value]
        
        return value
    
    def add_version(self, record_id, version_data):
        """Add a new version entry for a record (pending approval)."""
        try:
            existing = self.versions_collection.find_one({"recordId": record_id})
            if existing is None:
                doc = {"recordId": record_id, "versions": [version_data]}
                self.versions_collection.insert_one(doc)
            else:
                self.versions_collection.update_one({"recordId": record_id}, {"$push": {"versions": version_data}})
            return version_data
        except Exception as e:
            print(f"Error adding version: {e}")
            raise

    def get_record_history(self, record_id):
        """Return the history for a record including the current record and versions."""
        try:
            record = self.records_collection.find_one({"id": record_id}, {"_id": 0})
            if not record:
                 return {"record": None, "versions": []}

            versions_doc = self.versions_collection.find_one({"recordId": record_id}, {"_id": 0})
            versions = versions_doc.get("versions", []) if versions_doc else []
            
            # Clean records for JSON compliance
            record = self._clean_record(record)
            cleaned_versions = []
            for v in versions:
                 cleaned_versions.append(self._clean_record(v))
            
            return {"record": record, "versions": cleaned_versions}
        except Exception as e:
            print(f"Error getting record history: {e}")
            return {"record": None, "versions": []}

    def set_version_status(self, record_id, version_id, status, admin_user=None):
        """Set version status to 'approved' or 'declined'. If approved, apply to main record."""
        try:
            # Find the version
            doc = self.versions_collection.find_one({"recordId": record_id})
            if not doc:
                return False
            versions = doc.get("versions", [])
            target = None
            for v in versions:
                if v.get("versionId") == version_id:
                    target = v
                    break
            if not target:
                return False

            # Update status in array
            self.versions_collection.update_one(
                {"recordId": record_id, "versions.versionId": version_id},
                {"$set": {"versions.$.status": status, "versions.$.reviewedBy": admin_user, "versions.$.reviewedAt": datetime.now().isoformat()}}
            )

            if status == "approved":
                # Apply version snapshot to main record and update hashes
                data_snapshot = target.get("dataSnapshot", {})
                # Prepare fields to set (avoid overwriting id)
                update_fields = {k: v for k, v in data_snapshot.items() if k != "id"}
                # Also set the precomputed hashes if present
                if target.get("sha256Hash"):
                    update_fields["sha256Hash"] = target.get("sha256Hash")
                if target.get("quantumHash"):
                    update_fields["quantumHash"] = target.get("quantumHash")

                self.records_collection.update_one({"id": record_id}, {"$set": update_fields})

            return True
        except Exception as e:
            print(f"Error setting version status: {e}")
            return False

    def close(self):
        """Close the MongoDB connection."""
        if self.client:
            self.client.close()
            print("✓ MongoDB connection closed")

