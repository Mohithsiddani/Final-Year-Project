@echo off
REM Quick setup script for MongoDB integration
REM Usage: setup_mongodb.bat "mongodb+srv://user:pass@cluster.mongodb.net/dbname"

if "%1"=="" (
    echo.
    echo MongoDB Setup Script
    echo ====================
    echo.
    echo Usage: setup_mongodb.bat "YOUR_MONGODB_URI"
    echo.
    echo Example:
    echo setup_mongodb.bat "mongodb+srv://username:password@cluster0.abc123.mongodb.net/quantum_guard?retryWrites=true^&w=majority"
    echo.
    echo Steps:
    echo 1. Get MongoDB Atlas connection string from: https://www.mongodb.com/cloud/atlas
    echo 2. Run this script with your connection string
    echo 3. The environment variables will be set
    echo.
    pause
    exit /b 1
)

echo Setting environment variables...
setx DB_TYPE "mongodb"
setx MONGODB_URI "%1"

echo.
echo ✓ Environment variables set:
echo   DB_TYPE = mongodb
echo   MONGODB_URI = %1
echo.
echo Note: You may need to restart your terminal/IDE for changes to take effect.
echo.
pause
