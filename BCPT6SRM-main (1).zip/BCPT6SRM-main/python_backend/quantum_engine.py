import hashlib
import numpy as np
import json

try:
    from qiskit import QuantumCircuit, transpile, BasicAer
except ImportError:
    try:
        from qiskit import QuantumCircuit, transpile
        from qiskit.providers.basicaer import BasicAer
    except ImportError:
        # Fallback if qiskit is completely broken or unavailable
        BasicAer = None

class QuantumHashEngine:
    def __init__(self, num_qubits=8):
        self.num_qubits = num_qubits
        self.simulator = BasicAer.get_backend('qasm_simulator')

    def _data_to_circuit(self, data: str):
        """
        Encodes classical data into a quantum circuit.
        """
        # Create a SHA-256 hash of the data to get a consistent bitstring
        hash_digest = hashlib.sha256(data.encode()).digest()
        bitstring = bin(int.from_bytes(hash_digest, 'big'))[2:].zfill(256)
        
        qc = QuantumCircuit(self.num_qubits)
        
        # Simple encoding: apply RY rotations based on parts of the bitstring
        bits_per_qubit = len(bitstring) // self.num_qubits
        for i in range(self.num_qubits):
            chunk = bitstring[i*bits_per_qubit : (i+1)*bits_per_qubit]
            angle = int(chunk, 2) / (2**bits_per_qubit) * np.pi
            qc.ry(angle, i)
        
        # Entanglement layer
        for i in range(self.num_qubits - 1):
            qc.cx(i, i + 1)
        qc.cx(self.num_qubits - 1, 0)
        
        # Another rotation layer
        for i in range(self.num_qubits):
            qc.rz(np.pi / 4, i)
            
        qc.measure_all()
        return qc

    def generate_hash(self, data: str) -> str:
        """
        Generates a deterministic quantum-inspired hash.
        """
        if BasicAer is None:
            # Fallback to a purely classical "quantum-inspired" logic
            # Simulating some quantum complexity using trigonometric functions
            classical_hash = hashlib.sha256(data.encode()).hexdigest()
            entropy = sum(ord(c) for c in classical_hash)
            sim_quantum = hex(int(abs(np.sin(entropy)) * 10**8))[2:].zfill(8)
            return f"qh-{sim_quantum}-{classical_hash[:16]}"

        qc = self._data_to_circuit(data)
        
        # To make it deterministic for prototype validation:
        # We must seed BOTH the transpiler (circuit optimization) AND the simulator (measurement)
        transpiled_qc = transpile(qc, self.simulator, seed_transpiler=42)
        # Use a fixed seed to ensure the "quantum" result is deterministic
        result = self.simulator.run(transpiled_qc, shots=1024, seed_simulator=42).result()
        counts = result.get_counts()
        
        # Sort counts to get the most frequent measurement
        sorted_counts = sorted(counts.items(), key=lambda x: x[1], reverse=True)
        quantum_bits = sorted_counts[0][0]
        
        # Combine with a classical hash for extra complexity
        combined = f"qh-{quantum_bits}-{hashlib.sha256(data.encode()).hexdigest()[:16]}"
        return combined

if __name__ == "__main__":
    engine = QuantumHashEngine()
    test_data = "Patient: John Doe, Diagnosis: Healthy"
    print(f"Data: {test_data}")
    print(f"Hash: {engine.generate_hash(test_data)}")
