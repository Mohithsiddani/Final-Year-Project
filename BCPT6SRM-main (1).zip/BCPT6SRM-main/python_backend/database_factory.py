"""
Database adapter factory - seamlessly switch between CSV and MongoDB
"""
import os
import sys

def get_database(db_type=None, mongodb_uri=None):
    """
    Factory function to get database instance based on configuration.
    
    Args:
        db_type: 'csv' or 'mongodb'. If None, reads from environment or config.
        mongodb_uri: MongoDB connection string. If None, reads from environment.
    
    Returns:
        Database instance (either CSV or MongoDB)
    """
    
    # Default to environment or config if not provided
    if db_type is None:
        db_type = os.getenv("DB_TYPE", "csv").lower()
    
    if db_type == "mongodb":
        if mongodb_uri is None:
            mongodb_uri = os.getenv("MONGODB_URI")
        
        if not mongodb_uri:
            raise ValueError(
                "MongoDB selected but MONGODB_URI not provided. "
                "Set MONGODB_URI environment variable or pass it directly."
            )
        
        try:
            from database_mongodb import Database
            print(f"[DATABASE] Using MongoDB: {mongodb_uri.split('@')[0]}@...")
            return Database(mongodb_uri=mongodb_uri)
        except ImportError:
            raise ImportError("pymongo is required for MongoDB. Install with: pip install pymongo")
    
    elif db_type == "csv":
        from database import Database
        print("[DATABASE] Using CSV storage")
        return Database()
    
    else:
        raise ValueError(f"Unknown DB_TYPE: {db_type}. Use 'csv' or 'mongodb'")
