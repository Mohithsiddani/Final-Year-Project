from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid
import json
import sys
import os
import pandas as pd

# Handle both relative and absolute imports
try:
    from .database import Database
    from .blockchain import Blockchain
    from .quantum_engine import QuantumHashEngine
    from .auth import create_session, get_current_user, require_admin, users_db, sessions
except ImportError:
    # If relative imports fail, use absolute imports
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from database import Database
    from blockchain import Blockchain
    from quantum_engine import QuantumHashEngine
    from auth import create_session, get_current_user, require_admin, users_db

app = FastAPI(title="Quantum Hash Tamper Detection System - MongoDB Edition")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify the React app URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize MongoDB Atlas database
db = Database()
bc = Blockchain(db)
qe = QuantumHashEngine()

@app.get("/")
def root():
    return {
        "message": "Quantum Hash Tamper Detection System API",
        "docs": "/docs",
        "endpoints": {
            "records": "/records",
            "validate": "/blockchain/validate",
            "logs": "/logs"
        }
    }

# Models
class PersonalInfo(BaseModel):
    patientId: str
    patientName: str
    age: int
    gender: str
    contactNumber: str
    address: str

class MedicalInfo(BaseModel):
    diagnosis: str
    doctorName: str
    symptoms: str
    treatmentPlan: str
    medications: str

class BillingInfo(BaseModel):
    totalAmount: float
    insuranceProvider: str
    paymentStatus: str
    billingDate: str

class MedicalRecordRequest(BaseModel):
    personal: PersonalInfo
    medical: MedicalInfo
    billing: BillingInfo

class RecordUpdate(BaseModel):
    field: str
    newValue: str
    userRole: str

class LoginRequest(BaseModel):
    username: str
    password: str

class UserInfo(BaseModel):
    username: str
    role: str

# Authentication endpoints
@app.post("/auth/login")
def login(req: LoginRequest):
    if req.username not in users_db:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if users_db[req.username]["password"] != req.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_session(req.username)
    return {
        "token": token,
        "user": {
            "username": req.username,
            "role": users_db[req.username]["role"]
        }
    }

@app.get("/auth/me", response_model=UserInfo)
def get_me(current_user: dict = Depends(get_current_user)):
    return UserInfo(username=current_user["username"], role=current_user["role"])

@app.get("/records")
def get_records(current_user: dict = Depends(get_current_user)):
    records = db.get_all_records()
    # Add verification status to each record for the UI
    invalid_ids = bc.validate_chain(current_user)
    for r in records:
        r["isVerified"] = r["id"] not in invalid_ids
    return records

@app.get("/logs")
def get_logs(current_user: dict = Depends(require_admin)):
    return db.get_all_logs()

@app.post("/records")
def add_record(req: MedicalRecordRequest, current_user: dict = Depends(get_current_user)):
    record_id = f"REC-{str(uuid.uuid4())[:8].upper()}"
    
    # Flatten the nested structure for storage
    record_data = {
        "id": record_id,
        "patientId": req.personal.patientId,
        "patientName": req.personal.patientName,
        "age": req.personal.age,
        "gender": req.personal.gender,
        "contactNumber": req.personal.contactNumber,
        "address": req.personal.address,
        "diagnosis": req.medical.diagnosis,
        "doctorName": req.medical.doctorName,
        "symptoms": req.medical.symptoms,
        "treatmentPlan": req.medical.treatmentPlan,
        "medications": req.medical.medications,
        "totalAmount": req.billing.totalAmount,
        "insuranceProvider": req.billing.insuranceProvider,
        "paymentStatus": req.billing.paymentStatus,
        "billingDate": req.billing.billingDate,
    }
    
    # Process through blockchain logic
    block_record = bc.create_block_data(record_data)
    
    # Add user tracking information
    block_record["createdBy"] = current_user.get("username", "unknown")
    block_record["createdByRole"] = current_user.get("role", "unknown")
    
    # Save to CSV
    db.add_record(block_record)
    return block_record

@app.get("/blockchain/validate")
def validate_blockchain(current_user: dict = Depends(get_current_user)):
    invalid_ids = bc.validate_chain(current_user)
    return {
        "status": "valid" if not invalid_ids else "tampered",
        "invalidBlockIds": invalid_ids
    }

def make_json_safe(obj):
    """Recursively clean an object to be JSON-compliant."""
    import math
    if obj is None:
        return None
    elif isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    elif isinstance(obj, dict):
        return {k: make_json_safe(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [make_json_safe(item) for item in obj]
    elif isinstance(obj, str):
        return obj
    elif isinstance(obj, (int, bool)):
        return obj
    else:
        # Try to convert to string, or return None
        try:
            # Check if it's a pandas type that might have NaN
            if pd.isna(obj):
                return None
            return str(obj)
        except (TypeError, ValueError):
            return None

@app.get("/notifications")
def get_notifications(current_user: dict = Depends(require_admin)):
    """Get all notifications from the notifications CSV."""
    notifications = db.get_all_notifications()
    
    # Process notifications to ensure proper formatting
    processed_notifications = []
    for notif in notifications:
        # Handle read status - check for None first, then string, then pandas NaN
        is_read = notif.get("read", False)
        if is_read is None:
            is_read = False
        elif isinstance(is_read, str):
            is_read = is_read.lower() in ['true', '1', 'yes']
        elif isinstance(is_read, bool):
            is_read = bool(is_read)
        else:
            # Handle pandas NaN or other types
            try:
                if pd.isna(is_read):
                    is_read = False
                else:
                    is_read = bool(is_read)
            except (TypeError, ValueError):
                is_read = False
        
        notification = {
            "id": notif.get("id"),
            "recordId": notif.get("recordId"),
            "userId": notif.get("userId", "system"),
            "userRole": notif.get("userRole", "unknown"),
            "detectedAt": notif.get("detectedAt") or notif.get("createdAt"),
            "details": notif.get("details", f"Tamper detected in record {notif.get('recordId', 'unknown')}"),
            "read": bool(is_read)
        }
        
        # Clean the notification to ensure JSON compliance
        notification = make_json_safe(notification)
        processed_notifications.append(notification)
    
    # Sort by most recent (handle None values properly)
    def sort_key(x):
        dt = x.get("detectedAt")
        if dt is None or dt == "":
            return ""  # Empty string sorts last
        try:
            # Ensure dt is a string before returning
            return str(dt) if dt else ""
        except:
            return ""
    
    processed_notifications.sort(key=sort_key, reverse=True)
    
    # Final pass to ensure everything is JSON-compliant
    return make_json_safe(processed_notifications)


@app.get("/stream/notifications")
def stream_notifications(request: Request):
    """Stream new notifications to admin clients via Server-Sent Events (SSE).
    Uses MongoDB Change Streams to push newly inserted notifications in real-time.
    """
    # Allow token via query parameter for EventSource (browsers cannot set Authorization header)
    token = request.query_params.get("token")
    if not token or token not in sessions or sessions[token].get("role") != "admin":
        raise HTTPException(status_code=401, detail="Admin token required for SSE stream")

    def event_stream():
        try:
            # Watch for inserts on the notifications collection
            with db.notifications_collection.watch([
                {"$match": {"operationType": "insert"}}
            ], full_document='updateLookup') as stream:
                for change in stream:
                    full = change.get("fullDocument") or {}
                    notif = {
                        "id": full.get("id"),
                        "recordId": full.get("recordId"),
                        "userId": full.get("userId", "system"),
                        "userRole": full.get("userRole", "unknown"),
                        "detectedAt": full.get("detectedAt") or full.get("createdAt"),
                        "details": full.get("details", "Tamper detected"),
                        "read": bool(full.get("read", False))
                    }
                    payload = json.dumps(make_json_safe(notif))
                    yield f"data: {payload}\n\n"
        except Exception:
            # If change stream fails, silently stop the generator
            return

    return StreamingResponse(event_stream(), media_type="text/event-stream")
@app.post("/notifications/{notification_id}/read")
def mark_notification_read(notification_id: str, current_user: dict = Depends(require_admin)):
    """Mark a notification as read in the notifications CSV."""
    success = db.mark_notification_read(notification_id)
    if success:
        return {"message": "Notification marked as read", "notificationId": notification_id}
    else:
        raise HTTPException(status_code=404, detail="Notification not found")

@app.put("/simulate_tamper/{record_id}")
def simulate_tamper(record_id: str, update: RecordUpdate, current_user: dict = Depends(get_current_user)):
    records = db.get_all_records()
    record = next((r for r in records if r["id"] == record_id), None)
    
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    old_value = record.get(update.field, "")

    # Create a version proposal (pending approval) instead of overwriting the record
    # Build new data snapshot by copying current record and applying update
    data_snapshot = {**record}
    data_snapshot[update.field] = update.newValue

    # Remove fields that shouldn't be in snapshot
    data_snapshot.pop("_id", None)

    # Compute hashes for the proposed version using Blockchain helper
    proposed_sha256, proposed_quantum = bc.compute_hashes(data_snapshot)

    version_id = f"VER-{str(uuid.uuid4())[:8]}"
    version_entry = {
        "versionId": version_id,
        "dataSnapshot": data_snapshot,
        "sha256Hash": proposed_sha256,
        "quantumHash": proposed_quantum,
        "createdBy": current_user.get("username", "unknown"),
        "createdByRole": current_user.get("role", "unknown"),
        "createdAt": datetime.now().isoformat(),
        "status": "pending",
        "notes": f"Field '{update.field}' changed from '{old_value}' to '{update.newValue}'"
    }

    db.add_version(record_id, version_entry)

    # Log tamper event (this creates a notification) using previous hash and proposed new hash
    tamper_event = {
        "recordId": record_id,
        "previousHash": record.get("sha256Hash", ""),
        "newHash": proposed_sha256,
        "details": version_entry["notes"],
        "userId": current_user.get("username", "unknown"),
        "userRole": current_user.get("role", "unknown")
    }
    db.log_tamper_event(tamper_event)

    return {"message": "Tamper proposal created (pending admin approval)", "versionId": version_id}

@app.get("/records/{record_id}/verify")
def verify_record_endpoint(record_id: str, current_user: dict = Depends(get_current_user)):
    result = bc.verify_single_record(record_id)
    if not result:
        raise HTTPException(status_code=404, detail="Record not found")
    return result


@app.get("/records/{record_id}/history")
def get_record_history(record_id: str, current_user: dict = Depends(require_admin)):
    """Return the record and all proposed versions (history) for admin review."""
    history = db.get_record_history(record_id)
    if not history.get("record"):
        raise HTTPException(status_code=404, detail="Record not found")
    return history


@app.post("/records/{record_id}/versions/{version_id}/approve")
def approve_version(record_id: str, version_id: str, current_user: dict = Depends(require_admin)):
    ok = db.set_version_status(record_id, version_id, "approved", admin_user=current_user.get("username"))
    if not ok:
        raise HTTPException(status_code=404, detail="Version or record not found")
    return {"message": "Version approved and applied"}


@app.post("/records/{record_id}/versions/{version_id}/decline")
def decline_version(record_id: str, version_id: str, current_user: dict = Depends(require_admin)):
    ok = db.set_version_status(record_id, version_id, "declined", admin_user=current_user.get("username"))
    if not ok:
        raise HTTPException(status_code=404, detail="Version or record not found")
    return {"message": "Version declined"}


@app.post("/admin/backfill_versions")
def backfill_versions(current_user: dict = Depends(require_admin)):
    """Create initial approved version documents for existing records that lack history.
    Admin-only utility to backfill the `record_versions` collection.
    """
    records = db.get_all_records()
    created = 0
    for rec in records:
        hist = db.get_record_history(rec.get("id"))
        if not hist.get("versions"):
            init_version = {
                "versionId": f"VER-{datetime.now().timestamp()}",
                "dataSnapshot": rec,
                "sha256Hash": rec.get("sha256Hash"),
                "quantumHash": rec.get("quantumHash"),
                "createdBy": rec.get("createdBy", "system"),
                "createdByRole": rec.get("createdByRole", "system"),
                "createdAt": rec.get("timestamp", datetime.now().isoformat()),
                "status": "approved",
                "notes": "Backfilled initial version"
            }
            try:
                db.add_version(rec.get("id"), init_version)
                created += 1
            except Exception:
                pass
    return {"message": "Backfill complete", "created": created}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
