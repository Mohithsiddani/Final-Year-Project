from python_backend.database import Database
from python_backend.blockchain import Blockchain
import json
import hashlib
from datetime import datetime

print("Initializing Blockchain Repair...")
db = Database()
bc = Blockchain(db)

# Load current records
records = db.get_all_records()
print(f"Found {len(records)} records. Repairing...")

# Recalculate chain
for i, record in enumerate(records):
    # Fix previous hash
    if i == 0:
        record["previousHash"] = "genesis-0000"
    else:
        record["previousHash"] = records[i-1]["sha256Hash"]
    
    # Recalculate hashes
    # Manual serialization to match blockchain.py - EXACT COPY
    data_to_hash = json.dumps({
        "personal": {
            "patientId": str(record.get("patientId")) if record.get("patientId") is not None else "",
            "patientName": str(record.get("patientName")) if record.get("patientName") is not None else "",
            "age": int(float(record.get("age"))) if record.get("age") is not None else 0,
            "gender": str(record.get("gender")) if record.get("gender") is not None else "",
            "contactNumber": str(record.get("contactNumber")) if record.get("contactNumber") is not None else "",
            "address": str(record.get("address")) if record.get("address") is not None else "",
        },
        "medical": {
            "diagnosis": str(record.get("diagnosis")) if record.get("diagnosis") is not None else "",
            "doctorName": str(record.get("doctorName")) if record.get("doctorName") is not None else "",
            "symptoms": str(record.get("symptoms")) if record.get("symptoms") is not None else "",
            "treatmentPlan": str(record.get("treatmentPlan")) if record.get("treatmentPlan") is not None else "",
            "medications": str(record.get("medications")) if record.get("medications") is not None else "",
        },
        "billing": {
            "totalAmount": float(record.get("totalAmount")) if record.get("totalAmount") is not None else 0.0,
            "insuranceProvider": str(record.get("insuranceProvider")) if record.get("insuranceProvider") is not None else "",
            "paymentStatus": str(record.get("paymentStatus")) if record.get("paymentStatus") is not None else "",
            "billingDate": str(record.get("billingDate")) if record.get("billingDate") is not None else "",
        }
    }, sort_keys=True)
    
    # Calculate SHA256
    sha256 = hashlib.sha256(data_to_hash.encode()).hexdigest()
    record["sha256Hash"] = sha256
    
    # Calculate Quantum Hash
    quantum = bc.quantum_engine.generate_hash(data_to_hash)
    record["quantumHash"] = quantum
    
    print(f"Repaired Block {i+1}: {record['id']}")

# Save back to CSV
import pandas as pd
df = pd.DataFrame(records)
df.to_csv(db.records_path, index=False)

# Clear tamper logs
with open(db.logs_path, 'w') as f:
    f.write("id,recordId,previousHash,newHash,detectedAt,details\n")

print("Repair Complete! Chain is now valid.")
