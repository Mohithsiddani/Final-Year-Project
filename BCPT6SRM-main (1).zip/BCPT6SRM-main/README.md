# Quantum Guard

**Quantum Hash-Based Tamper Detection System**

Quantum Guard is a high-security medical record management platform that leverages **Classical Cryptography (SHA-256)** and **Quantum-Inspired Hashing (Qiskit)** to ensure unbeatable data integrity and immutability through blockchain technology.

🔗 **Repository:** [https://github.com/TrizenVenturesLLP/BCPT6SRM](https://github.com/TrizenVenturesLLP/BCPT6SRM)

---

## 🚀 Key Features

### 1. Dual-Layer Security
*   **SHA-256 (Classical):** Industry-standard cryptographic hashing for immediate verification.
*   **Quantum Hash (Future-Proof):** Quantum circuit simulation using **Qiskit** to generate complex, multi-dimensional data fingerprints using qubit rotations and entanglement.
*   **Deterministic Quantum Engine:** Uses a seeded quantum simulator to ensure hashing is deterministic and reproducible for verification.

### 2. Immutable Blockchain Ledger
*   **Custom Blockchain:** Every record is linked to the previous one via cryptographic hashes.
*   **Chain Integrity:** Modifying any past record breaks the chain, instantly flagging the system as compromised.
*   **Genesis Block:** First record serves as the foundation of the blockchain.

### 3. Real-Time Tamper Detection
*   **Background Watchdog:** The system automatically validates the entire blockchain every 30 seconds.
*   **Instant Alerts:** Validates data on-read. If data on disk (`records.csv`) does not match the stored hash, users are alerted immediately.
*   **Smart Logging:** Logs all tamper attempts to `tamper_logs.csv` with deduplication to prevent alert fatigue.

### 4. Role-Based Access Control (RBAC)
*   **Admin Role:** Full access to all features including tamper logs, blockchain explorer, and notifications.
*   **User Role:** Can create records and view records, but cannot see tamper status or admin features.
*   **Session Management:** Secure token-based authentication with HTTP Bearer tokens.

### 5. Admin Notification System
*   **Real-Time Alerts:** Admins receive instant notifications when tampering is detected.
*   **Notification Bell:** Visual indicator in the header showing unread notification count.
*   **Detailed Tracking:** Notifications include who tampered, what was changed, and when it occurred.
*   **Read/Unread Status:** Notifications can be marked as read to track what's been reviewed.

### 6. Record Verification System
*   **Individual Verification:** Click "Verify" on any record to check its integrity instantly.
*   **Hash Comparison:** Compares current SHA-256 and Quantum hashes with stored values.
*   **Detailed Results:** Shows verification status, hash matches/mismatches, and blockchain link integrity.
*   **Visual Indicators:** Color-coded badges (Verified/Tampered/Not Verified) for quick status identification.

### 7. Comprehensive Audit Trail
*   **Tamper Logs:** Complete history of all tamper events with user information.
*   **Record Creation Tracking:** Every record stores who created it and their role.
*   **Timestamp Tracking:** All events include precise timestamps for forensic analysis.

---

## 🛠️ Tech Stack

### Frontend
*   **Framework:** React 18 (Vite)
*   **Language:** TypeScript
*   **Styling:** Tailwind CSS + Shadcn UI Components
*   **HTTP Client:** Axios
*   **State Management:** React Context API (AuthContext)
*   **Routing:** React Router DOM v6

### Backend
*   **Framework:** FastAPI (Python)
*   **Quantum SDK:** Qiskit (IBM Quantum)
*   **Data Processing:** Pandas, NumPy
*   **Storage:** CSV-based local ledger (`records.csv`, `tamper_logs.csv`, `notifications.csv`)
*   **Authentication:** HTTP Bearer Token (session-based)
*   **API Documentation:** FastAPI auto-generated docs at `/docs`

---

## ⚙️ Setup & Installation

### Prerequisites

Before you begin, ensure you have the following installed:

*   **Python:** 3.8.10 or higher
*   **Node.js:** Latest LTS version (v18+)
*   **npm** or **yarn** package manager
*   **Git** (for cloning the repository)

### Step 1: Clone the Repository

```bash
git clone https://github.com/TrizenVenturesLLP/BCPT6SRM.git
cd BCPT6SRM
```

### Step 2: Backend Setup (Python)

1. Navigate to the backend directory:
```bash
cd python_backend
```

2. Install Python dependencies:
```bash
pip install -r requirements.txt
```

   **Note:** If you have multiple Python versions installed, use:
```bash
# On Windows:
py -3.8 -m pip install -r requirements.txt

# On Linux/Mac:
python3 -m pip install -r requirements.txt
```

3. Start the FastAPI server:
```bash
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

✅ **Backend is now running at:** `http://localhost:8000`
*   API Documentation: `http://localhost:8000/docs`
*   Alternative docs: `http://localhost:8000/redoc`

**Note:** Keep this terminal window open. The server will automatically reload when you make changes to the code.

### Step 3: Frontend Setup (React)

Open a **new terminal window** (keep the backend running):

1. Navigate to project root (if not already there):
```bash
cd BCPT6SRM
```

2. Install Node.js dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

✅ **Frontend is now running at:** `http://localhost:8080` (or the port shown in terminal)

### Step 4: Access the Application

1. Open your browser and navigate to: `http://localhost:8080`
2. You'll see the landing page with project features
3. Click **"Sign In"** button in the header to access the dashboard

---

## 🔑 Login Credentials

The system comes with pre-configured test accounts:

| Username | Password | Role | Access Level |
|----------|----------|------|--------------|
| `admin` | `admin123` | Admin | Full access to all features |
| `user1` | `user123` | User | Limited access (create/view records) |
| `user2` | `user123` | User | Limited access (create/view records) |

💡 **Tip:** On the login page, you can click the credential cards to auto-fill the username and password fields.

---

## 📖 Usage Guide

### Adding a Medical Record 📝

1. Log in to the dashboard using your credentials.
2. Click the **"Add Medical Record"** button.
3. Fill in the three sections:
   *   **Personal Information:** Patient ID, Name, Age, Gender, Contact Number, Address
   *   **Medical Information:** Diagnosis, Doctor Name, Symptoms, Treatment Plan, Medications
   *   **Billing Information:** Total Amount, Insurance Provider, Payment Status, Billing Date
4. Click **"Create Secure Record"**.
5. The system will:
   *   Generate both SHA-256 and Quantum-Inspired hashes
   *   Add the record to the blockchain
   *   Link it to the previous block
   *   Store it in `records.csv`
   *   Track who created the record

### Verifying Records ✅

#### Individual Record Verification

1. Navigate to the **"View All Records"** section on the dashboard.
2. Click the **"Verify"** button next to any record.
3. The system will:
   *   Recompute the SHA-256 hash from current data
   *   Recompute the Quantum hash from current data
   *   Compare both with stored blockchain hashes
   *   Check blockchain link integrity
   *   Display detailed results in a dialog

**Verification Results:**
*   🟢 **Verified:** Data is intact, all hashes match
*   🔴 **Tampered:** Data has been altered, hashes don't match
*   ⚪ **Not Verified:** Status unknown (for regular users)

#### Automatic Verification

*   The system automatically validates all records every 30 seconds.
*   Status badges update in real-time.
*   Tampered records are highlighted in red (admin only).

### Viewing Tamper Logs 🔍

**Admin Only:**

1. Click **"View Tamper Logs"** button in the Blockchain Explorer section.
2. View detailed information about:
   *   Which record was tampered with
   *   Who tampered with it (username and role)
   *   What field was changed
   *   Old value vs. new value
   *   When the tampering occurred
   *   Hash information

### Viewing the Blockchain 🔗

**Admin Only:**

1. Click **"View Full Blockchain"** button.
2. See the complete chronological chain:
   *   Genesis block (first record)
   *   All subsequent blocks
   *   Hash links between blocks
   *   Block indices
   *   Timestamps

### Admin Notifications 🔔

**Admin Only:**

1. Look for the notification bell icon in the header.
2. Click to see all tamper notifications.
3. Unread notifications show a red badge with count.
4. Click any notification to mark it as read.
5. Notifications include:
   *   Record ID that was tampered
   *   User who tampered
   *   Detection timestamp
   *   Details about the change

### Simulating Tampering 🧪

**For Testing (Admin Only):**

1. Click **"Simulate Tamper"** button.
2. Select a record ID.
3. Choose a field to modify.
4. Enter a new value.
5. Click **"Simulate Tamper"**.
6. The system will:
   *   Update the CSV file directly (bypassing hash update)
   *   Log the tamper event
   *   Create an admin notification
   *   Trigger validation on next check

---

## 📁 Project Structure

```
BCPT6SRM/
├── python_backend/              # FastAPI Backend
│   ├── main.py                 # API routes and FastAPI app
│   ├── database.py             # CSV database operations
│   ├── blockchain.py           # Blockchain logic and validation
│   ├── quantum_engine.py       # Quantum hash generation
│   ├── auth.py                 # Authentication and authorization
│   ├── requirements.txt        # Python dependencies
│   ├── records.csv             # Medical records storage
│   ├── tamper_logs.csv         # Tamper event logs
│   └── notifications.csv       # Admin notifications
│
├── src/                         # React Frontend
│   ├── components/             # React components
│   │   ├── ui/                # Shadcn UI components
│   │   ├── AddRecordDialog.tsx
│   │   ├── BlockchainDialog.tsx
│   │   ├── DashboardNav.tsx
│   │   ├── NotificationBell.tsx
│   │   ├── RecordsTable.tsx
│   │   ├── TamperLogsDialog.tsx
│   │   └── TamperSimulationDialog.tsx
│   ├── contexts/              # React contexts
│   │   └── AuthContext.tsx
│   ├── lib/                   # Utilities and API client
│   │   ├── api.ts            # Axios API client
│   │   ├── blockchain.ts     # Blockchain utilities
│   │   └── utils.ts
│   ├── pages/                 # Page components
│   │   ├── Dashboard.tsx
│   │   ├── Landing.tsx
│   │   ├── Login.tsx
│   │   └── NotFound.tsx
│   ├── App.tsx               # Main app component
│   └── main.tsx              # Entry point
│
├── public/                     # Static assets
├── package.json               # Node.js dependencies
├── vite.config.ts             # Vite configuration
├── tailwind.config.ts         # Tailwind CSS configuration
└── README.md                   # This file
```

---

## 🔌 API Documentation

### Authentication Endpoints

#### `POST /auth/login`
Login and receive authentication token.

**Request:**
```json
{
  "username": "admin",
  "password": "admin123"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "username": "admin",
    "role": "admin"
  }
}
```

#### `GET /auth/me`
Get current user information (requires authentication).

**Headers:**
```
Authorization: Bearer <token>
```

### Records Endpoints

#### `GET /records`
Get all medical records (requires authentication).

#### `POST /records`
Create a new medical record (requires authentication).

#### `GET /records/{record_id}/verify`
Verify a single record's integrity (requires authentication).

### Blockchain Endpoints

#### `GET /blockchain/validate`
Validate the entire blockchain (requires authentication).

### Admin Only Endpoints

#### `GET /logs`
Get all tamper logs (admin only).

#### `GET /notifications`
Get all notifications (admin only).

#### `POST /notifications/{notification_id}/read`
Mark a notification as read (admin only).

#### `PUT /simulate_tamper/{record_id}`
Simulate tampering on a record (requires authentication).

📚 **Full Interactive API Documentation:** Visit `http://localhost:8000/docs` when backend is running

---

## 🔐 Role-Based Access Control

### Admin Role ✅
*   View all records with tamper status
*   View tamper logs
*   View full blockchain
*   Receive notifications
*   Simulate tampering
*   Verify individual records

### User Role ✅
*   View all records (without tamper status)
*   Create new records
*   Verify individual records
*   ❌ Cannot see tamper status
*   ❌ Cannot view logs/blockchain
*   ❌ Cannot receive notifications

---

## 🚨 How Tamper Detection Works

1. **Record Creation:** Data is hashed using SHA-256 and Quantum algorithms
2. **Blockchain Storage:** Hash values stored in blockchain with previous hash link
3. **Continuous Monitoring:** System validates blockchain every 30 seconds
4. **Detection:** If data changes, hashes don't match → tampering detected
5. **Alerting:** Admin receives notification with details
6. **Logging:** Event logged to `tamper_logs.csv` with user info

---

## 🐛 Troubleshooting

### Backend Issues

**Problem:** Backend won't start
*   ✅ Check Python version: `python --version` (should be 3.8+)
*   ✅ Verify port 8000 is available
*   ✅ Reinstall dependencies: `pip install -r requirements.txt`
*   ✅ Make sure you're in the `python_backend` directory

**Problem:** Import errors
*   ✅ Check that all files exist in `python_backend/` directory
*   ✅ Verify all dependencies are installed correctly

### Frontend Issues

**Problem:** Frontend won't start
*   ✅ Check Node.js version: `node --version` (should be v18+)
*   ✅ Delete `node_modules` and run `npm install` again
*   ✅ Check if port 8080 is available

**Problem:** Can't connect to backend
*   ✅ Ensure backend is running on port 8000
*   ✅ Check browser console for CORS errors
*   ✅ Verify API URL in `src/lib/api.ts` is `http://localhost:8000`

### Authentication Issues

**Problem:** Login fails
*   ✅ Clear browser localStorage
*   ✅ Restart backend server (tokens are in-memory)
*   ✅ Verify credentials are correct (admin/admin123 or user1/user123)

---

## 📝 Data Storage

All data is stored in CSV files in the `python_backend/` directory:

*   **records.csv:** Contains all medical records with hash values and blockchain links
*   **tamper_logs.csv:** Contains all tamper events with user information and change details
*   **notifications.csv:** Contains admin notifications with read/unread status

Files are automatically created with proper headers if they don't exist. New columns are added gracefully without breaking existing data.

---

## 🔒 Security Considerations

### Current Implementation (Demo)
*   In-memory session tokens (lost on server restart)
*   Plain text passwords (for demo purposes only)
*   CSV file storage (not production-ready)
*   CORS allows all origins (`*`)

---
