import requests
import time

BASE_URL = "http://localhost:8000"

def test_add_and_validate():
    # 1. Add a record with complex types
    payload = {
        "personal": {
            "patientId": "TEST-001",  # String
            "patientName": "John Doe",
            "age": 45,  # Int
            "gender": "Male",
            "contactNumber": "1234567890",  # String number
            "address": "123 Test St",
        },
        "medical": {
            "diagnosis": "Flu",
            "doctorName": "Dr. Smith",
            "symptoms": "Fever",
            "treatmentPlan": "Rest",
            "medications": "Advil",
        },
        "billing": {
            "totalAmount": 150.50,  # Float
            "insuranceProvider": "Aetna",
            "paymentStatus": "Paid",
            "billingDate": "2026-01-19",
        }
    }
    
    print("Adding record...")
    res = requests.post(f"{BASE_URL}/records", json=payload)
    if res.status_code != 200:
        print(f"Failed to add record: {res.text}")
        return
    print(f"Record added: {res.json()['id']}")
    
    # 2. Validate
    print("Validating chain...")
    res = requests.get(f"{BASE_URL}/blockchain/validate")
    result = res.json()
    print(f"Validation result: {result}")
    
    if result["status"] == "valid" and len(result["invalidBlockIds"]) == 0:
        print("SUCCESS: Chain is valid!")
    else:
        print("FAILURE: Chain is invalid!")

if __name__ == "__main__":
    test_add_and_validate()
