import { CheckCircle2, XCircle, Hash, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HashStatusPanelProps {
  title: string;
  isMatched: boolean;
  hashPreview?: string;
  algorithm?: string;
}

const HashStatusPanel = ({ title, isMatched, hashPreview, algorithm }: HashStatusPanelProps) => {
  return (
    <div className={`p-5 rounded-xl border ${isMatched ? 'border-success/25 bg-success/5' : 'border-destructive/25 bg-destructive/5'} transition-all duration-200`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${isMatched ? 'bg-success/10' : 'bg-destructive/10'}`}>
            <Hash className={`w-5 h-5 ${isMatched ? 'text-success' : 'text-destructive'}`} />
          </div>
          <div>
            <h3 className="font-semibold text-foreground text-sm">{title}</h3>
            {algorithm && (
              <span className="text-xs text-muted-foreground">{algorithm}</span>
            )}
          </div>
        </div>
        <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full ${isMatched ? 'bg-success/10' : 'bg-destructive/10'}`}>
          {isMatched ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-success" />
              <span className="text-xs font-semibold text-success">VERIFIED</span>
            </>
          ) : (
            <>
              <XCircle className="w-3.5 h-3.5 text-destructive" />
              <span className="text-xs font-semibold text-destructive">MISMATCH</span>
            </>
          )}
        </div>
      </div>
      
      {hashPreview && (
        <div className="relative group">
          <div className="p-3 rounded-lg bg-muted/60 border border-border">
            <code className="text-[11px] font-mono text-muted-foreground break-all leading-relaxed">{hashPreview}</code>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute top-2 right-2 w-7 h-7 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <Copy className="w-3.5 h-3.5" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default HashStatusPanel;
