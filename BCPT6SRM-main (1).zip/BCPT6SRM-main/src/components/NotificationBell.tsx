import { Bell, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";

interface Notification {
  id: string;
  recordId: string;
  userId: string;
  userRole: string;
  detectedAt: string;
  details: string;
  read: boolean;
}

const NotificationBell = () => {
  const { isAdmin } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (isAdmin) {
      fetchNotifications();
      // Poll for new notifications every 10 seconds to catch tampering quickly
      const interval = setInterval(fetchNotifications, 10000);
      return () => clearInterval(interval);
    }
  }, [isAdmin]);

  // Refresh notifications when popover opens
  useEffect(() => {
    if (open && isAdmin) {
      fetchNotifications();
    }
  }, [open, isAdmin]);

  const fetchNotifications = async () => {
    if (!isAdmin) return;
    
    try {
      const data = await api.getNotifications();
      console.log("Fetched notifications:", data); // Debug log
      
      // Filter out any invalid notifications
      const validNotifications = (data || []).filter((n: any) => 
        n && n.id && n.recordId
      );
      
      console.log("Valid notifications:", validNotifications); // Debug log
      
      // Sort by most recent first
      const sorted = [...validNotifications].sort((a: Notification, b: Notification) => {
        const dateA = a.detectedAt ? new Date(a.detectedAt).getTime() : 0;
        const dateB = b.detectedAt ? new Date(b.detectedAt).getTime() : 0;
        return dateB - dateA;
      });
      
      setNotifications(sorted);
      const unread = sorted.filter((n: Notification) => !n.read).length;
      setUnreadCount(unread);
      console.log("Unread count:", unread); // Debug log
    } catch (error) {
      console.error("Failed to fetch notifications:", error);
      // Set empty array on error to avoid showing stale data
      setNotifications([]);
      setUnreadCount(0);
    }
  };

  const handleNotificationClick = async (notification: Notification) => {
    if (!notification.read) {
      try {
        await api.markNotificationRead(notification.id);
        // Update local state
        setNotifications(prev =>
          prev.map(n =>
            n.id === notification.id ? { ...n, read: true } : n
          )
        );
        setUnreadCount(prev => Math.max(0, prev - 1));
      } catch (error) {
        console.error("Failed to mark notification as read:", error);
      }
    }
  };

  if (!isAdmin) return null;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-1 -right-1 h-5 min-w-[20px] flex items-center justify-center p-0 text-xs font-semibold"
            >
              {unreadCount > 9 ? "9+" : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <div className="p-4 border-b">
          <h3 className="font-semibold">Security Notifications</h3>
          <p className="text-xs text-muted-foreground">
            Tamper detection alerts
          </p>
        </div>
        <div className="max-h-96 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">
              No notifications
            </div>
          ) : (
            <div className="divide-y">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 hover:bg-muted/50 cursor-pointer transition-colors ${
                    !notification.read ? 'bg-muted/30' : ''
                  }`}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">
                        {notification.userId && notification.userId !== "system" ? (
                          <>User <span className="font-mono text-destructive">{notification.userId}</span> tampered with record</>
                        ) : (
                          <>Tampering detected in record</>
                        )}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Record ID: <span className="font-mono">{notification.recordId}</span>
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {notification.details}
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {notification.detectedAt
                          ? format(new Date(notification.detectedAt), "MMM d, HH:mm:ss")
                          : "Recently"}
                      </p>
                    </div>
                    {!notification.read && (
                      <div className="w-2 h-2 rounded-full bg-destructive flex-shrink-0 mt-1" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default NotificationBell;
