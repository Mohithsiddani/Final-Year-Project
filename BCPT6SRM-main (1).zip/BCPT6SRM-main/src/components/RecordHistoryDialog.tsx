import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import { ArrowRight, ChevronRight, ChevronDown } from "lucide-react";

interface Props {
  open: boolean;
  recordId: string | null;
  onOpenChange: (open: boolean) => void;
}

// Helper to flatten object for diff comparison
const flattenObject = (obj: any, prefix = ''): Record<string, any> => {
  return Object.keys(obj || {}).reduce((acc: any, k) => {
    const pre = prefix.length ? prefix + '.' : '';
    if (typeof obj[k] === 'object' && obj[k] !== null && !Array.isArray(obj[k])) {
      Object.assign(acc, flattenObject(obj[k], pre + k));
    } else {
      acc[pre + k] = obj[k];
    }
    return acc;
  }, {});
};

const RecordSnapshot = ({ data }: { data: any }) => {
  if (!data) return null;

  const renderValue = (key: string, value: any, depth: number = 0) => {
    if (value === null || value === undefined) return <span className="text-muted-foreground italic">Empty</span>;

    if (typeof value === 'object' && !Array.isArray(value)) {
      return (
        <div key={key} className="mt-1">
          {key && <p className="font-semibold text-xs uppercase text-muted-foreground mb-1 ml-1">{key}</p>}
          <div className={`pl-2 border-l-2 border-border ml-1 grid gap-1 ${depth === 0 ? 'grid-cols-2 gap-x-4' : ''}`}>
            {Object.entries(value).map(([k, v]) => (
              <div key={k} className="mb-1">
                {typeof v === 'object' ? renderValue(k, v, depth + 1) : (
                  <div>
                    <span className="font-semibold text-muted-foreground block text-[10px] uppercase">{k}</span>
                    <span className="text-foreground text-sm break-words">{String(v)}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      );
    }

    return (
      <div key={key}>
        <span className="font-semibold text-muted-foreground block text-[10px] uppercase">{key}</span>
        <span className="text-foreground text-sm break-words">{String(value)}</span>
      </div>
    );
  };

  // Special handling for root object to avoid double nesting visual
  return (
    <div className="mt-2 p-3 bg-background/50 rounded-md border border-border text-sm">
      {Object.entries(data).map(([k, v]) => {
        // Skip internal fields
        if (['id', 'sha256Hash', 'quantumHash', 'blockIndex', 'previousHash', 'isVerified', 'timestamp'].includes(k)) return null;
        return (
          <div key={k} className="mb-2">
            {typeof v === 'object' ? renderValue(k, v) : renderValue(k, v)}
          </div>
        );
      })}
    </div>
  );
};

const DiffView = ({ oldData, newData }: { oldData: any, newData: any }) => {
  const flatOld = flattenObject(oldData);
  const flatNew = flattenObject(newData);

  const allKeys = Array.from(new Set([...Object.keys(flatOld), ...Object.keys(flatNew)]));
  const ignoreKeys = ['id', 'recordId', 'versionId', 'status', 'createdBy', 'createdAt', 'notes', 'sha256Hash', 'quantumHash', 'createdByRole', 'reviewedBy', 'reviewedAt', 'isVerified', 'timestamp', 'blockIndex', 'previousHash'];

  const diffs = allKeys.filter(k => {
    // Check if ignore key matches specifically or as a prefix (e.g., "metadata.createdAt")
    if (ignoreKeys.some(ik => k === ik || k.endsWith('.' + ik))) return false;
    return flatOld[k] !== flatNew[k];
  });

  if (!oldData && newData) {
    return (
      <div className="p-3 border border-green-200 bg-green-50 rounded-md text-sm">
        <p className="font-semibold text-green-700 mb-2">New Record Created</p>
        <RecordSnapshot data={newData} />
      </div>
    )
  }

  if (diffs.length === 0) return <p className="text-sm text-muted-foreground italic">No changes detected.</p>;

  return (
    <div className="space-y-2 mt-2">
      {diffs.map(k => (
        <div key={k} className="flex items-center text-sm p-2 bg-muted/40 rounded border border-border">
          <span className="font-bold uppercase text-[10px] text-muted-foreground w-32 shrink-0 truncate" title={k}>{k}</span>
          <div className="flex items-center gap-2 flex-1 overflow-hidden">
            <span className="text-destructive line-through truncate max-w-[45%] bg-destructive/5 px-1 rounded" title={String(flatOld[k])}>{flatOld[k] !== undefined ? String(flatOld[k]) : "Empty"}</span>
            <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0" />
            <span className="text-green-600 font-medium truncate max-w-[45%] bg-green-50 px-1 rounded" title={String(flatNew[k])}>{flatNew[k] !== undefined ? String(flatNew[k]) : "Empty"}</span>
          </div>
        </div>
      ))}
    </div>
  );
};

const RecordHistoryDialog: React.FC<Props> = ({ open, recordId, onOpenChange }) => {
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<any | null>(null);

  useEffect(() => {
    if (!open || !recordId) return;
    let mounted = true;
    setLoading(true);
    api.getRecordHistory(recordId).then((h) => {
      // Sort versions descending (newest first)
      if (h && h.versions) {
        h.versions.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      if (mounted) setHistory(h);
    }).catch((e) => console.error(e)).finally(() => mounted && setLoading(false));
    return () => { mounted = false; };
  }, [open, recordId]);

  if (!open) return null;

  // Determine the Truth: The latest APPROVED version.
  // If no approved version exists (rare), fallback to current record (risky but better than nothing).
  const currentVerified = history?.versions?.find((v: any) => v.status === 'approved')?.dataSnapshot || history?.record;

  const handleApprove = async (versionId: string) => {
    try {
      await api.approveVersion(recordId as string, versionId);
      // refresh
      const h = await api.getRecordHistory(recordId as string);
      if (h && h.versions) {
        h.versions.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      setHistory(h);
    } catch (e) { console.error(e); }
  };

  const handleDecline = async (versionId: string) => {
    try {
      await api.declineVersion(recordId as string, versionId);
      const h = await api.getRecordHistory(recordId as string);
      if (h && h.versions) {
        h.versions.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      setHistory(h);
    } catch (e) { console.error(e); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={() => onOpenChange(false)} />
      <div className="relative w-full max-w-3xl mx-4 bg-card rounded-lg shadow-lg p-6 z-10 max-h-[90vh] overflow-y-auto">
        <h3 className="text-lg font-semibold mb-2">Record History: {recordId}</h3>
        {loading && <p>Loading...</p>}
        {!loading && history && (
          <div className="space-y-6">
            <div className="p-4 bg-muted/30 rounded-lg border border-border">
              <h4 className="font-semibold flex items-center gap-2 mb-2">
                <span className="w-2 h-2 rounded-full bg-green-500"></span>
                Current Verified Record (Last Stable State)
              </h4>
              <div className="text-xs text-muted-foreground mb-3 font-mono">
                {/* Display hash of the VERIFIED snapshot, not the current possibly-tampered record */}
                <p>SHA256: {history?.versions?.find((v: any) => v.status === 'approved')?.sha256Hash || "N/A"}</p>
                <p>Quantum: {history?.versions?.find((v: any) => v.status === 'approved')?.quantumHash || "N/A"}</p>
              </div>
              <RecordSnapshot data={currentVerified} />
            </div>

            <div>
              <h4 className="font-semibold mb-3">History & Proposed Changes</h4>
              {history.versions.length === 0 && <p className="text-sm text-muted-foreground italic">No history versions available.</p>}
              <div className="space-y-4">
                {history.versions.map((v: any) => (
                  <div key={v.versionId} className="p-4 border rounded-lg bg-card shadow-sm">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm">{v.versionId}</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full uppercase font-medium ${v.status === 'approved' ? 'bg-green-100 text-green-700' :
                            v.status === 'declined' ? 'bg-red-100 text-red-700' :
                              'bg-yellow-100 text-yellow-700'
                            }`}>
                            {v.status}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">Edited by {v.createdBy} on {new Date(v.createdAt).toLocaleString()}</p>
                      </div>
                    </div>

                    <p className="text-sm italic text-muted-foreground mb-2">"{v.notes}"</p>

                    {/* If pending, show Diff against LAST APPROVED (currentVerified). Else show snapshot */}
                    {v.status === 'pending' ? (
                      <div className="mb-2">
                        <p className="text-xs font-semibold mb-1">Proposed Changes (vs Verified):</p>
                        <DiffView oldData={currentVerified} newData={v.dataSnapshot || v} />
                      </div>
                    ) : (
                      <div className="mb-2">
                        {/* For approved/declined versions, just show what that version looked like */}
                        <p className="text-xs font-semibold mb-1">Snapshot:</p>
                        <RecordSnapshot data={v.dataSnapshot || v} />
                      </div>
                    )}

                    <div className="mt-3 flex gap-2 justify-end">
                      {v.status === 'pending' && (
                        <>
                          <Button variant="ghost" size="sm" onClick={() => handleDecline(v.versionId)}>Decline Change</Button>
                          <Button variant="default" size="sm" onClick={() => handleApprove(v.versionId)}>Approve & Merge</Button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <Button variant="secondary" onClick={() => onOpenChange(false)}>Close</Button>
        </div>
      </div>
    </div>
  );
};

export default RecordHistoryDialog;
