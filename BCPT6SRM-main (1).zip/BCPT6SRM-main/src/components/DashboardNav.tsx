import { Shield, LogOut, User, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import NotificationBell from "./NotificationBell";

const DashboardNav = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border glass-effect">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center shadow-sm">
            <Shield className="w-5 h-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-sm font-semibold text-foreground tracking-tight leading-none">
              QuantumHash
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">Tamper Detection System</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {user && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-muted/50">
              <User className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-sm text-foreground font-medium">{user.username}</span>
              <span className="text-xs text-muted-foreground">({user.role})</span>
            </div>
          )}
          
          {/* Notification Bell - only visible for admin */}
          <NotificationBell />
          
          <div className="w-px h-8 bg-border" />
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleLogout}
            className="text-muted-foreground hover:text-foreground"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default DashboardNav;
