import { useState } from "react";
import {
  Shield,
  ShieldCheck,
  ShieldX,
  Loader2,
  Eye,
  AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { BlockchainRecord, VerificationResult, verifyRecord, createRecordDataString, generateSHA256Hash, generateQuantumHash } from "@/lib/blockchain";
import { api } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";

interface RecordsTableProps {
  records: BlockchainRecord[];
  onVerify: (recordId: string, result: VerificationResult) => void;
}

const RecordsTable = ({ records, onVerify }: RecordsTableProps) => {
  const { isAdmin } = useAuth();
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [selectedRecord, setSelectedRecord] = useState<BlockchainRecord | null>(null);
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);
  
  // Filter records for regular users - hide tampered status
  const displayRecords = isAdmin 
    ? records 
    : records.map(r => ({ ...r, isVerified: r.isVerified === false ? null : r.isVerified }));

  const handleVerify = async (record: BlockchainRecord) => {
    setVerifyingId(record.id);

    try {
      // Simulate network delay for UX
      await new Promise(resolve => setTimeout(resolve, 1000));

      const result = await api.verifyRecord(record.id);

      const verificationResult: VerificationResult = {
        sha256Valid: result.sha256Valid,
        quantumValid: result.quantumValid,
        currentSHA256: result.currentSHA256,
        currentQuantumHash: result.currentQuantumHash,
        storedSHA256: result.storedSHA256,
        storedQuantumHash: result.storedQuantumHash,
        isTampered: !result.isValid,
      };

      setVerificationResult(verificationResult);
      setSelectedRecord(record);
      onVerify(record.id, verificationResult);
    } catch (error) {
      console.error("Verification failed:", error);
      // Fallback or error handling could go here
    } finally {
      setVerifyingId(null);
    }
  };

  const getStatusBadge = (record: BlockchainRecord) => {
    if (record.isVerified === null) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-muted text-muted-foreground text-xs font-medium">
          <Shield className="w-3 h-3" />
          Not Verified
        </span>
      );
    }
    if (record.isVerified) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-success/10 text-success text-xs font-medium">
          <ShieldCheck className="w-3 h-3" />
          Verified
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-destructive/10 text-destructive text-xs font-medium">
        <ShieldX className="w-3 h-3" />
        Tampered
      </span>
    );
  };

  return (
    <>
      <div className="rounded-xl border border-border overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="font-semibold">Record ID</TableHead>
              <TableHead className="font-semibold">Patient</TableHead>
              <TableHead className="font-semibold">Diagnosis</TableHead>
              <TableHead className="font-semibold">Block #</TableHead>
              <TableHead className="font-semibold">Created By</TableHead>
              <TableHead className="font-semibold">Status</TableHead>
              <TableHead className="font-semibold text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {displayRecords.map((record) => (
              <TableRow key={record.id} className="hover:bg-muted/30">
                <TableCell className="font-mono text-xs">{record.id}</TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium text-sm">{record.patientName}</p>
                    <p className="text-xs text-muted-foreground">{record.patientId}</p>
                  </div>
                </TableCell>
                <TableCell className="text-sm">{record.diagnosis}</TableCell>
                <TableCell>
                  <span className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-primary/10 text-primary font-semibold text-sm">
                    {record.blockIndex}
                  </span>
                </TableCell>
                <TableCell>
                  {record.createdBy ? (
                    <div className="flex flex-col">
                      <span className="text-sm font-medium">{record.createdBy}</span>
                      {record.createdByRole && (
                        <span className="text-xs text-muted-foreground">{record.createdByRole}</span>
                      )}
                    </div>
                  ) : (
                    <span className="text-xs text-muted-foreground">Unknown</span>
                  )}
                </TableCell>
                <TableCell>{getStatusBadge(record)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedRecord(record);
                        setVerificationResult(null);
                      }}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => handleVerify(record)}
                      disabled={verifyingId === record.id}
                      className="gap-2"
                    >
                      {verifyingId === record.id ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          Verifying
                        </>
                      ) : (
                        <>
                          <Shield className="w-3.5 h-3.5" />
                          Verify
                        </>
                      )}
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Verification Result Dialog */}
      <Dialog open={selectedRecord !== null} onOpenChange={() => setSelectedRecord(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {verificationResult ? (
                verificationResult.isTampered ? (
                  <>
                    <ShieldX className="w-5 h-5 text-destructive" />
                    Verification Failed - Tampering Detected
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-5 h-5 text-success" />
                    Verification Successful
                  </>
                )
              ) : (
                <>
                  <Eye className="w-5 h-5 text-primary" />
                  Record Details: {selectedRecord?.id}
                </>
              )}
            </DialogTitle>
          </DialogHeader>

          {selectedRecord && (
            <div className="space-y-6">
              {/* Record Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Patient ID</p>
                  <p className="font-mono text-sm">{selectedRecord.patientId}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Patient Name</p>
                  <p className="text-sm font-medium">{selectedRecord.patientName}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Diagnosis</p>
                  <p className="text-sm">{selectedRecord.diagnosis}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Block Index</p>
                  <p className="text-sm font-semibold text-primary">{selectedRecord.blockIndex}</p>
                </div>
                {selectedRecord.createdBy && (
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">Created By</p>
                    <p className="text-sm font-medium">
                      {selectedRecord.createdBy}
                      {selectedRecord.createdByRole && (
                        <span className="text-muted-foreground ml-2">({selectedRecord.createdByRole})</span>
                      )}
                    </p>
                  </div>
                )}
              </div>

              {/* Hash Information */}
              <div className="space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Stored Hash Values</p>
                <div className="space-y-2">
                  <div className="p-3 rounded-lg bg-muted/50 border border-border">
                    <p className="text-xs text-muted-foreground mb-1">SHA-256 Hash</p>
                    <code className="text-xs font-mono break-all">{selectedRecord.sha256Hash}</code>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50 border border-border">
                    <p className="text-xs text-muted-foreground mb-1">Quantum Hash</p>
                    <code className="text-xs font-mono break-all">{selectedRecord.quantumHash}</code>
                  </div>
                </div>
              </div>

              {/* Verification Result */}
              {verificationResult && (
                <div className="space-y-3">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Verification Result</p>

                  {verificationResult.isTampered ? (
                    <div className="p-4 rounded-xl bg-destructive/10 border border-destructive/25">
                      <div className="flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold text-destructive">Data Tampering Detected!</p>
                          <p className="text-sm text-destructive/80 mt-1">
                            The current data hash does not match the stored blockchain hash.
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-success/10 border border-success/25">
                      <div className="flex items-start gap-3">
                        <ShieldCheck className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold text-success">Record Integrity Confirmed</p>
                          <p className="text-sm text-success/80 mt-1">
                            All hashes match. No tampering detected.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div className={`p-3 rounded-lg border ${verificationResult.sha256Valid ? 'bg-success/5 border-success/25' : 'bg-destructive/5 border-destructive/25'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        {verificationResult.sha256Valid ? (
                          <ShieldCheck className="w-4 h-4 text-success" />
                        ) : (
                          <ShieldX className="w-4 h-4 text-destructive" />
                        )}
                        <span className={`text-sm font-semibold ${verificationResult.sha256Valid ? 'text-success' : 'text-destructive'}`}>
                          SHA-256 {verificationResult.sha256Valid ? 'Match' : 'Mismatch'}
                        </span>
                      </div>
                    </div>
                    <div className={`p-3 rounded-lg border ${verificationResult.quantumValid ? 'bg-success/5 border-success/25' : 'bg-destructive/5 border-destructive/25'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        {verificationResult.quantumValid ? (
                          <ShieldCheck className="w-4 h-4 text-success" />
                        ) : (
                          <ShieldX className="w-4 h-4 text-destructive" />
                        )}
                        <span className={`text-sm font-semibold ${verificationResult.quantumValid ? 'text-success' : 'text-destructive'}`}>
                          Quantum Hash {verificationResult.quantumValid ? 'Match' : 'Mismatch'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {!verificationResult && (
                <Button onClick={() => handleVerify(selectedRecord)} className="w-full gap-2">
                  <Shield className="w-4 h-4" />
                  Verify This Record
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default RecordsTable;
