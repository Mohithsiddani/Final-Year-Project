import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { BlockchainRecord } from "@/lib/blockchain";
import { Link2, ShieldCheck, ShieldX, ArrowDown } from "lucide-react";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";

interface BlockchainDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    records: BlockchainRecord[];
}

const BlockchainDialog = ({ open, onOpenChange, records }: BlockchainDialogProps) => {
    const { isAdmin } = useAuth();
    
    // Only allow admin to view blockchain
    if (!isAdmin) {
        return null;
    }
    
    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Link2 className="w-5 h-5 text-primary" />
                        Blockchain Explorer
                    </DialogTitle>
                </DialogHeader>

                <ScrollArea className="h-[60vh] w-full pr-4 mt-4 rounded-md border p-4">
                    <div className="flex flex-col items-center space-y-0 pb-8">
                        {/* Genesis Block */}
                        <div className="relative w-full max-w-md">
                            <div className="p-4 rounded-xl border-2 border-primary bg-primary/5 shadow-sm relative z-10">
                                <div className="flex justify-between items-start mb-2">
                                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-primary text-primary-foreground">GENESIS</span>
                                    <span className="text-xs font-mono text-muted-foreground">Block #0</span>
                                </div>
                                <div className="space-y-1">
                                    <div className="flex justify-between text-xs">
                                        <span className="text-muted-foreground">Hash:</span>
                                        <span className="font-mono">0000...0000</span>
                                    </div>
                                    <div className="flex justify-between text-xs">
                                        <span className="text-muted-foreground">Previous:</span>
                                        <span className="font-mono">None</span>
                                    </div>
                                    <div className="flex justify-between text-xs">
                                        <span className="text-muted-foreground">Timestamp:</span>
                                        <span className="font-mono">System Start</span>
                                    </div>
                                </div>
                            </div>
                            <div className="absolute left-1/2 -bottom-6 w-0.5 h-6 bg-border -ml-px" />
                            <div className="absolute left-1/2 -bottom-6 text-muted-foreground transform -translate-x-1/2 translate-y-3 bg-background p-1">
                                <ArrowDown className="w-4 h-4" />
                            </div>
                        </div>

                        {/* Chain */}
                        {records.map((record, index) => (
                            <div key={record.id} className="relative w-full max-w-md mt-6 animate-in fade-in slide-in-from-bottom-2" style={{ animationDelay: `${index * 50}ms` }}>
                                <div className={`p-4 rounded-xl border-2 shadow-sm relative z-10 transition-colors ${record.isVerified === false
                                    ? "border-destructive bg-destructive/5"
                                    : record.isVerified === true
                                        ? "border-success bg-success/5"
                                        : "border-muted"
                                    }`}>
                                    <div className="flex justify-between items-start mb-3">
                                        <div className="flex items-center gap-2">
                                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-background border shadow-sm">
                                                Block #{record.blockIndex}
                                            </span>
                                            {record.isVerified === false ? (
                                                <span className="flex items-center gap-1 text-xs text-destructive font-medium">
                                                    <ShieldX className="w-3 h-3" /> Tampered
                                                </span>
                                            ) : (
                                                <span className="flex items-center gap-1 text-xs text-success font-medium">
                                                    <ShieldCheck className="w-3 h-3" /> Verified
                                                </span>
                                            )}
                                        </div>
                                        <span className="text-xs text-muted-foreground font-mono">{record.id}</span>
                                    </div>

                                    <div className="space-y-2 bg-background/50 p-2 rounded border border-border/50 text-xs font-mono">
                                        <div className="grid grid-cols-[60px_1fr] gap-2">
                                            <span className="text-muted-foreground">Prev:</span>
                                            <span className="truncate" title={record.previousHash}>
                                                {record.previousHash.substring(0, 20)}...
                                            </span>
                                        </div>
                                        <div className="grid grid-cols-[60px_1fr] gap-2">
                                            <span className="text-muted-foreground">Hash:</span>
                                            <span className={`truncate ${record.isVerified === false ? "text-destructive" : ""}`} title={record.sha256Hash}>
                                                {record.sha256Hash.substring(0, 20)}...
                                            </span>
                                        </div>
                                        <div className="grid grid-cols-[60px_1fr] gap-2">
                                            <span className="text-muted-foreground">Time:</span>
                                            <span className="truncate">
                                                {format(new Date(record.createdAt), "yyyy-MM-dd HH:mm:ss.SSS")}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                {/* Connector to next block if not last */}
                                {index < records.length - 1 && (
                                    <>
                                        <div className="absolute left-1/2 -bottom-6 w-0.5 h-6 bg-border -ml-px" />
                                        <div className="absolute left-1/2 -bottom-6 text-muted-foreground transform -translate-x-1/2 translate-y-3 bg-background p-1">
                                            <ArrowDown className="w-4 h-4" />
                                        </div>
                                    </>
                                )}
                            </div>
                        ))}
                    </div>
                </ScrollArea>
            </DialogContent>
        </Dialog>
    );
};

export default BlockchainDialog;
