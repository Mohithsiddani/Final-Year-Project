import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { AlertTriangle, CloudOff, User } from "lucide-react";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";

interface TamperLog {
    id: string;
    recordId: string;
    previousHash?: string;
    newHash?: string;
    detectedAt?: string;
    timestamp?: string;
    details?: string;
    userId?: string;
    userRole?: string;
    field?: string;
    oldValue?: string;
    newValue?: string;
}

interface TamperLogsDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
}

const TamperLogsDialog = ({ open, onOpenChange }: TamperLogsDialogProps) => {
    const { isAdmin } = useAuth();
    const [logs, setLogs] = useState<TamperLog[]>([]);
    const [loading, setLoading] = useState(false);
    
    // Only allow admin to view tamper logs
    if (!isAdmin) {
        return null;
    }

    useEffect(() => {
        if (open) {
            fetchLogs();
        }
    }, [open]);

    const fetchLogs = async () => {
        setLoading(true);
        try {
            const data = await api.getLogs();
            console.log("Fetched logs (raw):", data); // Debug log
            console.log("Number of logs received:", data?.length || 0); // Debug log
            
            // Filter out invalid logs - ensure id and recordId exist and are not null/empty
            const validLogs = (data || []).filter((log: any) => {
                const hasId = log && log.id && log.id !== null && log.id !== '';
                const hasRecordId = log && log.recordId && log.recordId !== null && log.recordId !== '';
                return hasId && hasRecordId;
            });
            
            console.log("Valid logs after filter:", validLogs.length); // Debug log
            
            // Process logs to ensure proper formatting
            const processedLogs = validLogs.map((log: any) => {
                // Use detectedAt if available, otherwise use timestamp
                const detectedAt = log.detectedAt || log.timestamp || null;
                
                // Generate details if not present
                let details = log.details;
                if (!details || details.trim() === '') {
                    if (log.field) {
                        const oldVal = log.oldValue || 'N/A';
                        const newVal = log.newValue || 'N/A';
                        details = `Field '${log.field}' was modified from '${oldVal}' to '${newVal}'`;
                    } else {
                        details = `Tamper detected in record ${log.recordId}`;
                    }
                }
                
                return {
                    ...log,
                    detectedAt,
                    details: details.trim()
                };
            });
            
            // Sort by detectedAt/timestamp desc, handling null values
            const sorted = processedLogs.sort((a: TamperLog, b: TamperLog) => {
                const dateA = a.detectedAt ? new Date(a.detectedAt).getTime() : 0;
                const dateB = b.detectedAt ? new Date(b.detectedAt).getTime() : 0;
                return dateB - dateA;
            });
            
            console.log("Processed and sorted logs:", sorted); // Debug log
            console.log("Final log count:", sorted.length); // Debug log
            setLogs(sorted);
        } catch (error) {
            console.error("Failed to fetch logs:", error);
            setLogs([]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl max-h-[80vh] flex flex-col">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 text-destructive">
                        <AlertTriangle className="w-5 h-5" />
                        Security Audit: Tamper Logs
                    </DialogTitle>
                </DialogHeader>

                <div className="flex-1 overflow-auto mt-4 border rounded-md">
                    {logs.length === 0 && !loading ? (
                        <div className="flex flex-col items-center justify-center p-8 text-muted-foreground">
                            <CloudOff className="w-8 h-8 mb-2 opacity-50" />
                            <p>No tamper events detected.</p>
                        </div>
                    ) : (
                        <Table>
                            <TableHeader>
                                <TableRow className="bg-muted/50">
                                    <TableHead className="w-[180px]">Detected At</TableHead>
                                    <TableHead className="w-[150px]">Tampered By</TableHead>
                                    <TableHead className="w-[120px]">Record ID</TableHead>
                                    <TableHead>Details</TableHead>
                                    <TableHead className="w-[100px] text-right">Hash Diff</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {logs.map((log) => (
                                    <TableRow key={log.id} className="hover:bg-muted/10">
                                        <TableCell className="font-mono text-xs">
                                            {log.detectedAt ? (
                                                format(new Date(log.detectedAt), "MMM d, HH:mm:ss")
                                            ) : (
                                                <span className="text-muted-foreground">N/A</span>
                                            )}
                                        </TableCell>
                                        <TableCell>
                                            {log.userId && log.userId !== "system" ? (
                                                <div className="flex items-center gap-2">
                                                    <div className="w-8 h-8 rounded-full bg-destructive/10 flex items-center justify-center">
                                                        <User className="w-4 h-4 text-destructive" />
                                                    </div>
                                                    <div>
                                                        <p className="font-semibold text-destructive text-sm">
                                                            {log.userId}
                                                        </p>
                                                        {log.userRole && (
                                                            <p className="text-xs text-muted-foreground">
                                                                {log.userRole}
                                                            </p>
                                                        )}
                                                    </div>
                                                </div>
                                            ) : (
                                                <div className="flex items-center gap-2">
                                                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                                                        <User className="w-4 h-4 text-muted-foreground" />
                                                    </div>
                                                    <div>
                                                        <p className="font-medium text-muted-foreground text-sm">
                                                            System
                                                        </p>
                                                    </div>
                                                </div>
                                            )}
                                        </TableCell>
                                        <TableCell className="font-medium text-destructive font-mono text-xs">
                                            {log.recordId}
                                        </TableCell>
                                        <TableCell className="text-sm">
                                            <div>
                                                <p className="font-medium">{log.details || "Tamper detected"}</p>
                                                {log.field && (
                                                    <p className="text-xs text-muted-foreground mt-1">
                                                        Field: <span className="font-mono">{log.field}</span>
                                                        {log.oldValue && log.newValue && (
                                                            <span> • {log.oldValue} → {log.newValue}</span>
                                                        )}
                                                    </p>
                                                )}
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-right font-mono text-xs text-muted-foreground">
                                            {log.newHash ? (
                                                <span title={`New: ${log.newHash}`}>
                                                    {log.newHash.substring(0, 8)}...
                                                </span>
                                            ) : (
                                                <span className="text-muted-foreground">N/A</span>
                                            )}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default TamperLogsDialog;
