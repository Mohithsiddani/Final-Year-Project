import { useState } from "react";
import { Plus, Shield, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { BlockchainRecord } from "@/lib/blockchain";
import { api } from "@/lib/api";

interface AddRecordDialogProps {
  onAddRecord: (record: BlockchainRecord) => void;
  currentBlockIndex: number;
  previousHash: string;
}

const AddRecordDialog = ({ onAddRecord, currentBlockIndex, previousHash }: AddRecordDialogProps) => {
  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    // Personal Information
    patientId: "",
    patientName: "",
    age: "",
    gender: "",
    contactNumber: "",
    address: "",
    // Medical Information
    diagnosis: "",
    doctorName: "",
    symptoms: "",
    treatmentPlan: "",
    medications: "",
    // Billing Information
    totalAmount: "",
    insuranceProvider: "",
    paymentStatus: "Pending",
    billingDate: new Date().toISOString().split('T')[0],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const newRecord = await api.addRecord({
        personal: {
          patientId: formData.patientId,
          patientName: formData.patientName,
          age: parseInt(formData.age),
          gender: formData.gender,
          contactNumber: formData.contactNumber,
          address: formData.address,
        },
        medical: {
          diagnosis: formData.diagnosis,
          doctorName: formData.doctorName,
          symptoms: formData.symptoms,
          treatmentPlan: formData.treatmentPlan,
          medications: formData.medications,
        },
        billing: {
          totalAmount: parseFloat(formData.totalAmount),
          insuranceProvider: formData.insuranceProvider,
          paymentStatus: formData.paymentStatus,
          billingDate: formData.billingDate,
        }
      });

      // Convert to BlockchainRecord format
      const blockchainRecord: BlockchainRecord = {
        id: newRecord.id,
        patientId: newRecord.patientId,
        patientName: newRecord.patientName,
        diagnosis: newRecord.diagnosis,
        createdAt: newRecord.timestamp,
        data: `${formData.symptoms} - ${formData.treatmentPlan}`,
        sha256Hash: newRecord.sha256Hash,
        quantumHash: newRecord.quantumHash,
        blockIndex: newRecord.blockIndex,
        previousHash: newRecord.previousHash,
        isVerified: null,
        lastVerifiedAt: null,
      };

      onAddRecord(blockchainRecord);
      setOpen(false);
      setFormData({
        patientId: "",
        patientName: "",
        age: "",
        gender: "",
        contactNumber: "",
        address: "",
        diagnosis: "",
        doctorName: "",
        symptoms: "",
        treatmentPlan: "",
        medications: "",
        totalAmount: "",
        insuranceProvider: "",
        paymentStatus: "Pending",
        billingDate: new Date().toISOString().split('T')[0],
      });
    } catch (error) {
      console.error("Failed to add record:", error);
      alert("Failed to add record. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="default" className="h-12 justify-start px-5">
          <Plus className="w-4 h-4 mr-3" />
          Add Medical Record
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            Add New Medical Record
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 max-h-[70vh] overflow-y-auto pr-2">
          {/* Section 1: Personal Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-primary uppercase tracking-wider">1. Personal & Contact Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="patientId">Patient ID *</Label>
                <Input
                  id="patientId"
                  placeholder="e.g., PAT-001"
                  value={formData.patientId}
                  onChange={(e) => setFormData(prev => ({ ...prev, patientId: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="patientName">Patient Name *</Label>
                <Input
                  id="patientName"
                  placeholder="Full name"
                  value={formData.patientName}
                  onChange={(e) => setFormData(prev => ({ ...prev, patientName: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="age">Age *</Label>
                <Input
                  id="age"
                  type="number"
                  placeholder="e.g., 35"
                  value={formData.age}
                  onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender *</Label>
                <Input
                  id="gender"
                  placeholder="e.g., Male/Female"
                  value={formData.gender}
                  onChange={(e) => setFormData(prev => ({ ...prev, gender: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactNumber">Contact Number *</Label>
                <Input
                  id="contactNumber"
                  placeholder="e.g., +1-555-0123"
                  value={formData.contactNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, contactNumber: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="address">Address *</Label>
                <Input
                  id="address"
                  placeholder="Full address"
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                  required
                />
              </div>
            </div>
          </div>

          {/* Section 2: Medical Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-primary uppercase tracking-wider">2. Medical & Doctor-Related Data</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="diagnosis">Diagnosis *</Label>
                <Input
                  id="diagnosis"
                  placeholder="Primary diagnosis"
                  value={formData.diagnosis}
                  onChange={(e) => setFormData(prev => ({ ...prev, diagnosis: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="doctorName">Doctor Name *</Label>
                <Input
                  id="doctorName"
                  placeholder="Attending physician"
                  value={formData.doctorName}
                  onChange={(e) => setFormData(prev => ({ ...prev, doctorName: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="symptoms">Symptoms *</Label>
                <Textarea
                  id="symptoms"
                  placeholder="Patient symptoms"
                  value={formData.symptoms}
                  onChange={(e) => setFormData(prev => ({ ...prev, symptoms: e.target.value }))}
                  rows={2}
                  required
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="treatmentPlan">Treatment Plan *</Label>
                <Textarea
                  id="treatmentPlan"
                  placeholder="Recommended treatment"
                  value={formData.treatmentPlan}
                  onChange={(e) => setFormData(prev => ({ ...prev, treatmentPlan: e.target.value }))}
                  rows={2}
                  required
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="medications">Medications *</Label>
                <Input
                  id="medications"
                  placeholder="Prescribed medications"
                  value={formData.medications}
                  onChange={(e) => setFormData(prev => ({ ...prev, medications: e.target.value }))}
                  required
                />
              </div>
            </div>
          </div>

          {/* Section 3: Billing Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-primary uppercase tracking-wider">3. Billing & Payment Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="totalAmount">Total Amount *</Label>
                <Input
                  id="totalAmount"
                  type="number"
                  step="0.01"
                  placeholder="e.g., 1500.00"
                  value={formData.totalAmount}
                  onChange={(e) => setFormData(prev => ({ ...prev, totalAmount: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="insuranceProvider">Insurance Provider *</Label>
                <Input
                  id="insuranceProvider"
                  placeholder="e.g., Blue Cross"
                  value={formData.insuranceProvider}
                  onChange={(e) => setFormData(prev => ({ ...prev, insuranceProvider: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="paymentStatus">Payment Status *</Label>
                <Input
                  id="paymentStatus"
                  placeholder="e.g., Pending/Paid"
                  value={formData.paymentStatus}
                  onChange={(e) => setFormData(prev => ({ ...prev, paymentStatus: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="billingDate">Billing Date *</Label>
                <Input
                  id="billingDate"
                  type="date"
                  value={formData.billingDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, billingDate: e.target.value }))}
                  required
                />
              </div>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-muted/50 border border-border">
            <p className="text-xs text-muted-foreground">
              <strong>Block #{currentBlockIndex}</strong> will be created with SHA-256 and Quantum hashes for tamper detection.
            </p>
          </div>

          <Button type="submit" className="w-full gap-2" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Creating Record & Generating Hashes...
              </>
            ) : (
              <>
                <Shield className="w-4 h-4" />
                Create Secure Record
              </>
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddRecordDialog;
