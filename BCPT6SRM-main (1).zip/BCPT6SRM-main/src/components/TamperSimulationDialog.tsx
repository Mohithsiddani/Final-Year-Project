import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertTriangle } from "lucide-react";
import { useState } from "react";
import { api } from "@/lib/api";
import { useToast } from "@/components/ui/use-toast";
import { BlockchainRecord } from "@/lib/blockchain";

interface TamperSimulationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  records: BlockchainRecord[];
  onTamperComplete: () => void;
}

const TamperSimulationDialog = ({
  open,
  onOpenChange,
  records,
  onTamperComplete,
}: TamperSimulationDialogProps) => {
  const { toast } = useToast();
  const [selectedRecordId, setSelectedRecordId] = useState<string>("");
  const [selectedField, setSelectedField] = useState<string>("");
  const [newValue, setNewValue] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);

  const editableFields = [
    { value: "patientName", label: "Patient Name" },
    { value: "diagnosis", label: "Diagnosis" },
    { value: "doctorName", label: "Doctor Name" },
    { value: "symptoms", label: "Symptoms" },
    { value: "treatmentPlan", label: "Treatment Plan" },
    { value: "medications", label: "Medications" },
    { value: "totalAmount", label: "Total Amount" },
    { value: "paymentStatus", label: "Payment Status" },
  ];

  const selectedRecord = records.find((r) => r.id === selectedRecordId);

  const handleTamper = async () => {
    if (!selectedRecordId || !selectedField || !newValue) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please select a record, field, and enter a new value.",
      });
      return;
    }

    setIsLoading(true);
    try {
      await api.simulateTamper(selectedRecordId, {
        field: selectedField,
        newValue: newValue,
        userRole: "user", // This will be overridden by backend with actual user role
      });

      toast({
        title: "Tamper Simulation Complete",
        description: `Field "${selectedField}" has been modified. The system will detect this tampering within 30 seconds.`,
      });

      // Reset form
      setSelectedRecordId("");
      setSelectedField("");
      setNewValue("");
      onOpenChange(false);
      onTamperComplete();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Tamper Simulation Failed",
        description: error.response?.data?.detail || "An error occurred",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="w-5 h-5" />
            Simulate Data Tampering
          </DialogTitle>
          <DialogDescription>
            This will modify a record without updating its hash, simulating unauthorized tampering. The system will detect this within 30 seconds.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="record">Select Record</Label>
            <Select value={selectedRecordId} onValueChange={setSelectedRecordId}>
              <SelectTrigger id="record">
                <SelectValue placeholder="Choose a record to tamper with" />
              </SelectTrigger>
              <SelectContent>
                {records.map((record) => (
                  <SelectItem key={record.id} value={record.id}>
                    {record.patientName} - {record.diagnosis} ({record.id})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedRecord && (
            <>
              <div className="space-y-2">
                <Label htmlFor="field">Select Field to Tamper</Label>
                <Select value={selectedField} onValueChange={setSelectedField}>
                  <SelectTrigger id="field">
                    <SelectValue placeholder="Choose a field to modify" />
                  </SelectTrigger>
                  <SelectContent>
                    {editableFields.map((field) => (
                      <SelectItem key={field.value} value={field.value}>
                        {field.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedField && (
                <div className="space-y-2">
                  <Label htmlFor="oldValue">Current Value</Label>
                  <Input
                    id="oldValue"
                    value={
                      selectedRecord[selectedField as keyof BlockchainRecord]?.toString() || ""
                    }
                    disabled
                    className="bg-muted"
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="newValue">New Value (Tampered)</Label>
                <Input
                  id="newValue"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder="Enter the tampered value"
                />
              </div>
            </>
          )}

          <div className="flex gap-2 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleTamper}
              className="flex-1"
              disabled={isLoading || !selectedRecordId || !selectedField || !newValue}
            >
              {isLoading ? "Tampering..." : "Simulate Tamper"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TamperSimulationDialog;
