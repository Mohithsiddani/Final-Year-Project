import { LucideIcon } from "lucide-react";

interface StatusCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  subtitle?: string;
  status?: "valid" | "invalid" | "neutral";
}

const StatusCard = ({ icon: Icon, label, value, subtitle, status = "neutral" }: StatusCardProps) => {
  const statusStyles = {
    valid: "border-success/25 bg-success/5",
    invalid: "border-destructive/25 bg-destructive/5",
    neutral: "border-border bg-card",
  };

  const iconStyles = {
    valid: "bg-success/10 text-success",
    invalid: "bg-destructive/10 text-destructive",
    neutral: "bg-accent text-primary",
  };

  const valueStyles = {
    valid: "text-success",
    invalid: "text-destructive",
    neutral: "text-foreground",
  };

  return (
    <div className={`p-5 rounded-xl border ${statusStyles[status]} card-elevated transition-all duration-200`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">{label}</p>
          <p className={`text-2xl font-bold tracking-tight ${valueStyles[status]}`}>{value}</p>
          {subtitle && (
            <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
          )}
        </div>
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${iconStyles[status]}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
};

export default StatusCard;
