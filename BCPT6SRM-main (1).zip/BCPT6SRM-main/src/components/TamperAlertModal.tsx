import React from "react";
import { Button } from "@/components/ui/button";

interface Props {
  open: boolean;
  notification: any | null;
  onClose: () => void;
  onAcknowledge?: (id: string) => void;
  onViewHistory?: (recordId: string) => void;
}

const TamperAlertModal: React.FC<Props> = ({ open, notification, onClose, onAcknowledge, onViewHistory }) => {
  if (!open || !notification) return null;

  // content parsing
  const details = notification.details || "";
  const storedMatch = details.match(/Stored:\s*([a-fA-F0-9]+)/);
  const computedMatch = details.match(/Computed:\s*([a-fA-F0-9]+)/);

  const storedHash = storedMatch ? storedMatch[1] : "N/A";
  const computedHash = computedMatch ? computedMatch[1] : "N/A";

  // Clean details to remove the hash part for display if needed, or just keep it as is.
  // We will display specific hash cards now.

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-4 bg-card rounded-lg shadow-lg p-6 z-10 border-2 border-destructive">
        <div className="flex items-center gap-2 mb-4">
          <div className="h-3 w-3 rounded-full bg-destructive animate-pulse" />
          <h2 className="text-lg font-semibold text-foreground">Security Alert: Data Integrity Compromised</h2>
        </div>

        <p className="text-sm text-muted-foreground mb-4">
          The system detected a mismatch between the stored immutable record and the current data.
        </p>

        <div className="bg-muted/10 rounded-md p-3 mb-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="font-semibold">Record ID:</span>
            <span className="font-mono">{notification.recordId}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="font-semibold">Detected:</span>
            <span>{notification.detectedAt}</span>
          </div>
        </div>

        <div className="grid gap-3 mb-6">
          <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-md">
            <p className="text-xs font-semibold text-green-700 uppercase mb-1">Original Hash (Trusted)</p>
            <p className="text-xs font-mono break-all text-green-800">{storedHash}</p>
          </div>
          <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
            <p className="text-xs font-semibold text-destructive uppercase mb-1">Computed Hash (Tampered)</p>
            <p className="text-xs font-mono break-all text-destructive">{computedHash}</p>
          </div>
        </div>

        <div className="flex justify-between items-center gap-2">
          <div>
            <Button variant="secondary" onClick={() => notification.recordId && onViewHistory && onViewHistory(notification.recordId)} className="mr-2">
              View History Changes
            </Button>
            <Button variant="ghost" onClick={onClose}>Close</Button>
          </div>
          <Button
            variant="destructive"
            onClick={() => {
              if (onAcknowledge && notification.id) onAcknowledge(notification.id);
              onClose();
            }}
          >
            Acknowledge Alert
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TamperAlertModal;
