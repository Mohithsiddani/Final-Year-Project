import { Shield, Lock, Link2, Bell, Cpu, Database, ArrowRight, Fingerprint, Users, Eye, AlertTriangle, CheckCircle2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import FeatureCard from "@/components/FeatureCard";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const Landing = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const features = [
    {
      icon: Lock,
      title: "Dual Hashing Algorithm",
      description: "SHA-256 combined with Quantum-Inspired hashing provides multi-layer security verification for maximum data integrity.",
    },
    {
      icon: Link2,
      title: "Blockchain Immutability",
      description: "Distributed ledger technology ensures unauthorized modifications are instantly detected and permanently logged.",
    },
    {
      icon: Cpu,
      title: "Real-time Verification",
      description: "Continuous integrity monitoring with instant validation of record authenticity every 30 seconds.",
    },
    {
      icon: Bell,
      title: "Admin Notifications",
      description: "Real-time alert system with notification bell for admins to track all tamper attempts immediately.",
    },
    {
      icon: Users,
      title: "Role-Based Access Control",
      description: "Secure user management with Admin and User roles, ensuring proper access control and audit trails.",
    },
    {
      icon: Eye,
      title: "Tamper Detection",
      description: "Advanced detection system that identifies unauthorized changes and tracks which user made modifications.",
    },
    {
      icon: AlertTriangle,
      title: "Security Audit Logs",
      description: "Comprehensive tamper logs with detailed information about who, what, when, and how data was modified.",
    },
    {
      icon: CheckCircle2,
      title: "Record Verification",
      description: "Individual record verification system allows instant checking of any medical record's integrity status.",
    },
  ];

  const technologies = ["Python", "FastAPI", "React", "TypeScript", "Blockchain", "SHA-256", "Quantum Simulation", "Tailwind CSS"];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center shadow-sm">
              <Shield className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-semibold text-foreground tracking-tight text-lg">Quantum Guard</span>
          </div>
          <Button 
            onClick={() => navigate(user ? "/dashboard" : "/login")}
            className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm"
            size="default"
          >
            {user ? "Go to Dashboard" : "Sign In"}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16">
        {/* Background patterns */}
        <div className="absolute inset-0 pattern-grid opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-b from-accent/40 via-transparent to-transparent" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent/30 rounded-full blur-3xl" />
        
        <div className="container relative z-10 py-24 md:py-32 lg:py-40">
          <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
            {/* Badge */}
           

            {/* Title */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-[1.1] tracking-tight mb-6">
              Quantum Hash–Based{" "}
              <span className="gradient-text">Tamper Detection</span>{" "}
              System
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl text-muted-foreground font-medium mb-4 max-w-2xl">
              Secure Medical Records using SHA-256, Quantum-Inspired Hashing, and Blockchain Technology
            </p>

            {/* Description */}
            <p className="text-base text-muted-foreground/80 max-w-xl mb-10 leading-relaxed">
              An advanced system that detects unauthorized data modifications in medical records 
              through dual hashing mechanisms and blockchain-based immutability.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                variant="hero" 
                size="xl" 
                onClick={() => navigate(user ? "/dashboard" : "/login")}
                className="min-w-[220px] group"
              >
                <Database className="w-5 h-5 mr-2" />
                {user ? "Enter Dashboard" : "Get Started"}
                <ArrowRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button 
                variant="heroOutline" 
                size="xl"
                className="min-w-[220px]"
              >
                View Project Overview
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 pt-16 border-t border-border/50">
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">100%</div>
                <div className="text-sm text-muted-foreground">Tamper Detection</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">24/7</div>
                <div className="text-sm text-muted-foreground">Monitoring</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">Real-time</div>
                <div className="text-sm text-muted-foreground">Alerts</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">Immutable</div>
                <div className="text-sm text-muted-foreground">Blockchain</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-card border-y border-border">
        <div className="container">
          <div className="text-center mb-16">
            <p className="text-sm font-medium text-primary mb-3 uppercase tracking-wider">Security Features</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 tracking-tight">
              Multi-Layer Protection System
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              Advanced security mechanisms working in tandem to protect medical record integrity with real-time monitoring and instant alerts
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="text-center mb-16">
            <p className="text-sm font-medium text-primary mb-3 uppercase tracking-wider">How It Works</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 tracking-tight">
              Secure Your Medical Records
            </h2>
          </div>
          
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex gap-6 items-start">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-primary font-bold text-lg">1</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Record Creation</h3>
                <p className="text-muted-foreground">
                  When a medical record is created, it's processed through dual hashing algorithms (SHA-256 and Quantum-Inspired) 
                  and added to an immutable blockchain ledger with cryptographic linking.
                </p>
              </div>
            </div>
            
            <div className="flex gap-6 items-start">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-primary font-bold text-lg">2</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Continuous Monitoring</h3>
                <p className="text-muted-foreground">
                  The system continuously validates the blockchain integrity every 30 seconds, checking for any unauthorized 
                  modifications or tampering attempts.
                </p>
              </div>
            </div>
            
            <div className="flex gap-6 items-start">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-primary font-bold text-lg">3</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Instant Detection</h3>
                <p className="text-muted-foreground">
                  If any tampering is detected, the system immediately logs the event with details about who made the change, 
                  what was changed, and when it occurred.
                </p>
              </div>
            </div>
            
            <div className="flex gap-6 items-start">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-primary font-bold text-lg">4</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Admin Alerts</h3>
                <p className="text-muted-foreground">
                  Administrators receive real-time notifications through the notification bell, allowing them to take immediate 
                  action on any security incidents.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-muted/30">
        <div className="container">
          <div className="flex flex-col items-center text-center">
            {/* Technologies */}
            <p className="text-sm font-medium text-primary mb-4 uppercase tracking-wider">Built With</p>
            <div className="flex flex-wrap justify-center gap-3 mb-8">
              {technologies.map((tech, index) => (
                <span
                  key={index}
                  className="px-4 py-2 text-sm font-medium bg-card text-foreground rounded-lg border border-border shadow-sm hover:shadow-md transition-shadow"
                >
                  {tech}
                </span>
              ))}
            </div>
            
            {/* CTA */}
            <div className="mt-8">
              <Button 
                onClick={() => navigate(user ? "/dashboard" : "/login")}
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                {user ? "Access Dashboard" : "Get Started Now"}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            
           

            {/* Copyright */}
            <p className="text-xs text-muted-foreground/60 mt-6">
              © 2026 Quantum Hash Security Research 
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
