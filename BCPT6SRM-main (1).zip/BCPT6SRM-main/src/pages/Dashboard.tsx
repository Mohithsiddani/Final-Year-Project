import {
  Database,
  Shield,
  Clock,
  Eye,
  Edit3,
  Link2,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Activity,
  RefreshCw,
  ShieldCheck,
  ShieldX
} from "lucide-react";
import { Button } from "@/components/ui/button";
import StatusCard from "@/components/StatusCard";
import HashStatusPanel from "@/components/HashStatusPanel";
import DashboardNav from "@/components/DashboardNav";
import RecordsTable from "@/components/RecordsTable";
import AddRecordDialog from "@/components/AddRecordDialog";
import { useState, useMemo, useEffect } from "react";
import { BlockchainRecord, VerificationResult } from "@/lib/blockchain";
import { api } from "@/lib/api";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import TamperAlertModal from "@/components/TamperAlertModal";
import RecordHistoryDialog from "@/components/RecordHistoryDialog";
import TamperLogsDialog from "@/components/TamperLogsDialog";
import BlockchainDialog from "@/components/BlockchainDialog";
import TamperSimulationDialog from "@/components/TamperSimulationDialog";

const Dashboard = () => {
  const { toast } = useToast();
  const { isAdmin } = useAuth();
  const [records, setRecords] = useState<BlockchainRecord[]>([]);
  const [showRecords, setShowRecords] = useState(false);
  const [showTamperLogs, setShowTamperLogs] = useState(false);
  const [showBlockchain, setShowBlockchain] = useState(false);
  const [showTamperSimulation, setShowTamperSimulation] = useState(false);
  const [lastCheckTime, setLastCheckTime] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState(true);
  const [showTamperAlert, setShowTamperAlert] = useState(false);
  const [tamperedRecordIds, setTamperedRecordIds] = useState<string[]>([]);
  const [tamperModalOpen, setTamperModalOpen] = useState(false);
  const [tamperModalData, setTamperModalData] = useState<any | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historyRecordId, setHistoryRecordId] = useState<string | null>(null);

  // Fetch records from backend
  const fetchRecords = async () => {
    setIsLoading(true);
    try {
      const data = await api.getRecords();
      // Convert backend records to BlockchainRecord format
      const convertedRecords: BlockchainRecord[] = data.map((r: any) => ({
        id: r.id,
        patientId: r.patientId,
        patientName: r.patientName,
        diagnosis: r.diagnosis,
        createdAt: r.timestamp,
        data: r.medical_info || "",
        sha256Hash: r.sha256Hash,
        quantumHash: r.quantumHash,
        blockIndex: r.blockIndex,
        previousHash: r.previousHash,
        isVerified: r.isVerified !== undefined ? r.isVerified : null,
        lastVerifiedAt: null,
        createdBy: r.createdBy,
        createdByRole: r.createdByRole,
      }));
      setRecords(convertedRecords);
      setLastCheckTime(new Date());
    } catch (error) {
      console.error("Failed to fetch records:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch records and validate blockchain on mount
  useEffect(() => {
    fetchRecords();
    validateBlockchain();
  }, []);

  // Periodic blockchain validation (every 30 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      validateBlockchain();
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  // SSE subscription for real-time tamper notifications (admins only)
  useEffect(() => {
    if (!isAdmin) return;
    let es: EventSource | null = null;
    const token = localStorage.getItem('token');
    if (token) {
      const url = `http://localhost:8000/stream/notifications?token=${token}`;
      try {
        es = new EventSource(url);

        es.onopen = () => console.debug('SSE connected to', url);

        es.onmessage = (e: MessageEvent) => {
          try {
            const payload = JSON.parse(e.data);
            console.debug('SSE message:', payload);
            // Update state to show centered modal for admins
            setTamperedRecordIds(prev => {
              if (!payload.recordId) return prev;
              const next = [payload.recordId, ...prev];
              // keep unique order-preserving
              return next.filter((v, i, a) => a.indexOf(v) === i);
            });
            setTamperModalData(payload);
            setTamperModalOpen(true);
            setShowTamperAlert(true);
          } catch (err) {
            console.error('Failed to parse SSE payload', err);
          }
        };

        es.onerror = (err) => {
          console.warn('SSE connection errored', err);
          // Close and fallback to polling
          try { es.close(); } catch (e) { }
        };
      } catch (err) {
        console.warn('Failed to create EventSource', err);
      }
    } else {
      console.warn('No token found in localStorage; SSE not started');
    }

    // Polling fallback: check unread notifications every 5s if SSE not delivering
    let pollInterval: any = null;
    const startPolling = () => {
      pollInterval = setInterval(async () => {
        try {
          const notifs = await api.getNotifications();
          if (!notifs || notifs.length === 0) return;
          // find first unread
          const unread = notifs.find((n: any) => !n.read);
          if (unread) {
            console.debug('Polling found unread notification', unread);
            setTamperedRecordIds(prev => {
              if (!unread.recordId) return prev;
              const next = [unread.recordId, ...prev];
              return next.filter((v, i, a) => a.indexOf(v) === i);
            });
            setTamperModalData(unread);
            setTamperModalOpen(true);
            setShowTamperAlert(true);
          }
        } catch (err) {
          // ignore polling errors (auth, network), will retry
          console.warn('Polling notifications failed', err);
        }
      }, 5000);
    };

    // If SSE not connected within 1s, start polling
    const sseWatch = setTimeout(() => {
      if (!es || es.readyState === EventSource.CLOSED) {
        startPolling();
      }
    }, 1000);

    return () => {
      if (es) try { es.close(); } catch (e) { }
      if (pollInterval) clearInterval(pollInterval);
      clearTimeout(sseWatch);
    };
  }, [isAdmin]);

  // Validate blockchain integrity
  const validateBlockchain = async () => {
    try {
      const result = await api.validateBlockchain();
      if (result.invalidBlockIds && result.invalidBlockIds.length > 0) {
        setTamperedRecordIds(result.invalidBlockIds);

        // Only update tamper status for admin users
        if (isAdmin) {
          // Only show alert banner if state changes to avoid spamming
          // No toast notification - notifications will appear in the notification bell
          if (!showTamperAlert) {
            setShowTamperAlert(true);
          }

          // Update records with tamper status (admin can see tamper status)
          setRecords(prev => prev.map(record => ({
            ...record,
            isVerified: result.invalidBlockIds.includes(record.id) ? false : record.isVerified
          })));
        } else {
          // Regular users: don't update tamper status, keep records as verified
          // This way regular users don't see that records are tampered
        }
      } else {
        setTamperedRecordIds([]);
        setShowTamperAlert(false);
      }
    } catch (error) {
      console.error("Blockchain validation failed:", error);
    }
  };

  // Calculate status from records
  const stats = useMemo(() => {
    const verified = records.filter(r => r.isVerified !== null);
    const tampered = records.filter(r => r.isVerified === false);
    const valid = records.filter(r => r.isVerified === true);

    return {
      totalRecords: records.length,
      verifiedCount: verified.length,
      tamperedCount: isAdmin ? tampered.length : 0, // Hide tampered count from regular users
      validCount: valid.length,
      blockchainValid: isAdmin ? (tampered.length === 0) : true, // Always show valid to regular users
      hasTampering: isAdmin ? (tampered.length > 0) : false, // Hide tampering status from regular users
    };
  }, [records, isAdmin]);

  const handleAddRecord = (newRecord: BlockchainRecord) => {
    fetchRecords(); // Refresh from backend
  };

  const handleVerify = (recordId: string, result: VerificationResult) => {
    setRecords(prev => prev.map(record =>
      record.id === recordId
        ? {
          ...record,
          isVerified: !result.isTampered,
          lastVerifiedAt: new Date().toISOString()
        }
        : record
    ));
    setLastCheckTime(new Date());
  };

  const handleRefresh = () => {
    fetchRecords();
    validateBlockchain();
  };

  const getTimeSinceLastCheck = () => {
    const diff = Math.floor((new Date().getTime() - lastCheckTime.getTime()) / 1000);
    if (diff < 60) return `${diff} sec ago`;
    return `${Math.floor(diff / 60)} min ago`;
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      <TamperLogsDialog open={showTamperLogs} onOpenChange={setShowTamperLogs} />
      <BlockchainDialog open={showBlockchain} onOpenChange={setShowBlockchain} records={records} />
      <TamperSimulationDialog
        open={showTamperSimulation}
        onOpenChange={setShowTamperSimulation}
        records={records}
        onTamperComplete={() => {
          fetchRecords();
          validateBlockchain();
        }}
      />

      <main className="container py-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground tracking-tight">Dashboard</h1>
            <p className="text-sm text-muted-foreground mt-1">Monitor and manage medical record integrity</p>
          </div>
          <Button variant="outline" size="sm" className="gap-2" onClick={handleRefresh}>
            <RefreshCw className="w-4 h-4" />
            Reset Verification
          </Button>
        </div>

        {/* Alert Banner - Only visible to admin */}
        {showTamperAlert && isAdmin && (
          <div className="mb-6 p-4 rounded-xl bg-destructive/10 border border-destructive/25 flex items-start gap-4 animate-in fade-in slide-in-from-top-4">
            <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-5 h-5 text-destructive animate-pulse" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-destructive flex items-center justify-between">
                Security Alert: Tampering Detected
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 hover:bg-destructive/20 text-destructive"
                  onClick={() => setShowTamperAlert(false)}
                >
                  <span className="sr-only">Dismiss</span>
                  <ShieldX className="h-4 w-4" />
                </Button>
              </h3>
              <p className="text-sm text-destructive/90 mt-1">
                The blockchain integrity check failed. The following records have been modified without authorization:
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {tamperedRecordIds.map(id => (
                  <span key={id} className="px-2 py-1 rounded-md bg-destructive/20 text-destructive text-xs font-mono font-medium border border-destructive/20">
                    {id}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {!showTamperAlert && stats.validCount > 0 && (
          <div className="mb-6 p-4 rounded-xl bg-success/8 border border-success/20 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="font-semibold text-success">System Integrity Verified</p>
              <p className="text-sm text-success/80 mt-0.5">
                {stats.validCount} of {stats.totalRecords} records verified successfully. Blockchain is secure.
              </p>
            </div>
          </div>
        )}

        {/* Section A: Status Overview */}
        <section className="mb-8">
          <p className="section-header">System Status</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <StatusCard
              icon={Database}
              label="Total Records"
              value={stats.totalRecords}
              subtitle={`${stats.verifiedCount} verified`}
              status="neutral"
            />
            <StatusCard
              icon={Shield}
              label="Blockchain Status"
              value={stats.blockchainValid ? "Valid" : "Tampered"}
              subtitle={`${records.length} blocks in chain`}
              status={stats.blockchainValid ? "valid" : "invalid"}
            />
            <StatusCard
              icon={Clock}
              label="Last Check"
              value={getTimeSinceLastCheck()}
              subtitle="Verify records below"
              status="neutral"
            />
          </div>
        </section>

        {/* Section B: Record Operations */}
        <section className="mb-8">
          <p className="section-header">Record Operations</p>
          <div className="p-6 rounded-xl bg-card border border-border card-elevated">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <AddRecordDialog
                onAddRecord={handleAddRecord}
                currentBlockIndex={records.length + 1}
                previousHash={records.length > 0 ? records[records.length - 1].sha256Hash : "genesis-0000"}
              />
              <Button
                variant={showRecords ? "default" : "secondary"}
                className="h-12 justify-start px-5"
                onClick={() => setShowRecords(!showRecords)}
              >
                <Eye className="w-4 h-4 mr-3" />
                {showRecords ? "Hide Records" : "View All Records"}
              </Button>
              <Button
                variant="outline"
                className="h-12 justify-start px-5 border-destructive/50 text-destructive hover:bg-destructive/10"
                onClick={() => setShowTamperSimulation(true)}
              >
                <AlertTriangle className="w-4 h-4 mr-3" />
                Simulate Tampering
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-4 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              All operations are logged and verified against the blockchain
            </p>
          </div>
        </section>

        {/* Records Table */}
        {showRecords && (
          <section className="mb-8">
            <p className="section-header">Medical Records</p>
            <RecordsTable records={records} onVerify={handleVerify} />
          </section>
        )}

        {/* Section C: Hash & Security Status */}
        <section className="mb-8">
          <p className="section-header">Hash Verification Summary</p>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <HashStatusPanel
              title="SHA-256 Verification"
              algorithm="Standard Cryptographic Hash"
              isMatched={!stats.hasTampering || stats.verifiedCount === 0}
              hashPreview={records.length > 0 ? records[records.length - 1].sha256Hash : "No records"}
            />
            <HashStatusPanel
              title="Quantum Hash Verification"
              algorithm="Quantum-Inspired Algorithm"
              isMatched={!stats.hasTampering || stats.verifiedCount === 0}
              hashPreview={records.length > 0 ? records[records.length - 1].quantumHash : "No records"}
            />
          </div>
        </section>

        {/* Section D: Blockchain & Logs - Admin Only */}
        {isAdmin && (
          <section>
            <p className="section-header">Blockchain Explorer</p>
            <div className="p-6 rounded-xl bg-card border border-border card-elevated">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <Button variant="outline" className="h-12 justify-start px-5" onClick={() => setShowBlockchain(true)}>
                  <Link2 className="w-4 h-4 mr-3" />
                  View Full Blockchain
                </Button>
                <Button variant="outline" className="h-12 justify-start px-5" onClick={() => setShowTamperLogs(true)}>
                  <FileText className="w-4 h-4 mr-3" />
                  View Tamper Logs
                </Button>
              </div>

              {/* Blockchain Preview */}
              <div className="p-4 rounded-lg bg-muted/40 border border-border">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Recent Blocks</h3>
                  <span className="text-xs text-muted-foreground">{records.length + 1} blocks (including genesis)</span>
                </div>
                <div className="flex items-center gap-3 overflow-x-auto pb-2">
                  {/* Genesis Block */}
                  <div className="flex-shrink-0 w-24 h-24 rounded-lg border-2 border-primary bg-primary/5 shadow-sm flex flex-col items-center justify-center transition-all hover:scale-105 cursor-pointer">
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Block</span>
                    <span className="text-2xl font-bold text-foreground">0</span>
                    <span className="text-[10px] font-semibold text-primary mt-0.5">GENESIS</span>
                  </div>

                  {/* Record Blocks */}
                  {records.slice(0, 5).map((record) => (
                    <div
                      key={record.id}
                      className={`flex-shrink-0 w-24 h-24 rounded-lg border-2 flex flex-col items-center justify-center transition-all hover:scale-105 cursor-pointer ${record.isVerified === false
                        ? 'border-destructive bg-destructive/5'
                        : record.isVerified === true
                          ? 'border-success bg-success/5'
                          : 'border-border bg-card hover:border-primary/50'
                        }`}
                    >
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Block</span>
                      <span className="text-2xl font-bold text-foreground">{record.blockIndex}</span>
                      {record.isVerified === true && (
                        <ShieldCheck className="w-3.5 h-3.5 text-success mt-0.5" />
                      )}
                      {record.isVerified === false && (
                        <ShieldX className="w-3.5 h-3.5 text-destructive mt-0.5" />
                      )}
                      {record.isVerified === null && (
                        <span className="text-[10px] text-muted-foreground mt-0.5">Pending</span>
                      )}
                    </div>
                  ))}

                  {records.length > 5 && (
                    <div className="flex-shrink-0 w-16 h-24 flex flex-col items-center justify-center text-muted-foreground">
                      <span className="text-2xl">...</span>
                      <span className="text-[10px]">+{records.length - 5} more</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Centered Tamper Alert Modal for Admins */}
      <TamperAlertModal
        open={tamperModalOpen}
        notification={tamperModalData}
        onClose={() => setTamperModalOpen(false)}
        onAcknowledge={async (id: string, recordId?: string) => {
          try {
            await api.markNotificationRead(id);
            // "Make it verified" - manually update local state to green
            if (!recordId && tamperModalData?.recordId) recordId = tamperModalData.recordId;

            if (recordId) {
              handleVerify(recordId, {
                isTampered: false,
                sha256Valid: true,
                quantumValid: true,
                currentSHA256: "",
                currentQuantumHash: "",
                storedSHA256: "",
                storedQuantumHash: ""
              });

              // Also remove from tampered list to clear banner
              setTamperedRecordIds(prev => prev.filter(tid => tid !== recordId));

              // If it was the only one, hide alert
              if (tamperedRecordIds.length <= 1 && tamperedRecordIds.includes(recordId)) {
                setShowTamperAlert(false);
              }
            }
          } catch (err) {
            console.error("Failed to mark notification read", err);
          }
        }}
        onViewHistory={(recordId: string) => {
          setHistoryRecordId(recordId);
          setHistoryOpen(true);
        }}
      />

      <RecordHistoryDialog open={historyOpen} recordId={historyRecordId} onOpenChange={setHistoryOpen} />

      {/* Footer */}
      <footer className="border-t border-border py-4 mt-8">
        <div className="container">
          <p className="text-xs text-muted-foreground text-center">
            Quantum Hash Tamper Detection System • Academic Prototype • v1.0
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
