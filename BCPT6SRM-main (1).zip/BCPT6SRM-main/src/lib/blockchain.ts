// Simulated hashing functions for academic demonstration
// In production, these would use actual cryptographic libraries

export interface MedicalRecord {
  id: string;
  patientId: string;
  patientName: string;
  diagnosis: string;
  createdAt: string;
  data: string;
}

export interface BlockchainRecord extends MedicalRecord {
  sha256Hash: string;
  quantumHash: string;
  blockIndex: number;
  previousHash: string;
  isVerified: boolean | null;
  lastVerifiedAt: string | null;
  createdBy?: string;
  createdByRole?: string;
}

// Simulated SHA-256 hash generation
export const generateSHA256Hash = (data: string): string => {
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  
  // Convert to hex-like string
  const hashStr = Math.abs(hash).toString(16).padStart(8, '0');
  return `sha256-${hashStr}${'0'.repeat(56 - hashStr.length)}${hashStr}`;
};

// Simulated Quantum-inspired hash generation
export const generateQuantumHash = (data: string): string => {
  let hash = 0;
  const prime = 31;
  
  for (let i = 0; i < data.length; i++) {
    hash = (hash * prime + data.charCodeAt(i)) % Number.MAX_SAFE_INTEGER;
  }
  
  // Add quantum-inspired entropy simulation
  const quantumFactor = Math.sin(hash) * 10000;
  const finalHash = Math.abs(Math.floor(hash ^ (quantumFactor * 1000)));
  
  const hashStr = finalHash.toString(16).padStart(8, '0');
  return `qh-${hashStr}${'f'.repeat(56 - hashStr.length)}${hashStr}`;
};

// Create a data string from record for hashing
export const createRecordDataString = (record: MedicalRecord): string => {
  return JSON.stringify({
    id: record.id,
    patientId: record.patientId,
    patientName: record.patientName,
    diagnosis: record.diagnosis,
    createdAt: record.createdAt,
    data: record.data,
  });
};

// Verify record integrity by comparing current hash with stored hash
export interface VerificationResult {
  sha256Valid: boolean;
  quantumValid: boolean;
  currentSHA256: string;
  currentQuantumHash: string;
  storedSHA256: string;
  storedQuantumHash: string;
  isTampered: boolean;
}

export const verifyRecord = (record: BlockchainRecord, currentData: MedicalRecord): VerificationResult => {
  const dataString = createRecordDataString(currentData);
  const currentSHA256 = generateSHA256Hash(dataString);
  const currentQuantumHash = generateQuantumHash(dataString);
  
  const sha256Valid = currentSHA256 === record.sha256Hash;
  const quantumValid = currentQuantumHash === record.quantumHash;
  
  return {
    sha256Valid,
    quantumValid,
    currentSHA256,
    currentQuantumHash,
    storedSHA256: record.sha256Hash,
    storedQuantumHash: record.quantumHash,
    isTampered: !sha256Valid || !quantumValid,
  };
};

// Generate unique ID
export const generateRecordId = (): string => {
  return `REC-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
};
