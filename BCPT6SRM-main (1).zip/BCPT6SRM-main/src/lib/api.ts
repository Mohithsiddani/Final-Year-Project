import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000';

// Set up axios interceptor to add token to requests
const token = localStorage.getItem('token');
if (token) {
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
}

// Add response interceptor to handle 401 errors
axios.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            localStorage.removeItem('token');
            delete axios.defaults.headers.common['Authorization'];
            // Redirect to login if not already there
            if (window.location.pathname !== '/login') {
                window.location.href = '/login';
            }
        }
        return Promise.reject(error);
    }
);

export interface MedicalRecord {
    id: string;
    patientId: string;
    patientName: string;
    age: number;
    gender: string;
    contactNumber: string;
    address: string;
    diagnosis: string;
    doctorName: string;
    symptoms: string;
    treatmentPlan: string;
    medications: string;
    totalAmount: number;
    insuranceProvider: string;
    paymentStatus: string;
    billingDate: string;
    sha256Hash: string;
    quantumHash: string;
    timestamp: string;
    blockIndex: number;
    previousHash: string;
    isVerified?: boolean;
    createdBy?: string;
    createdByRole?: string;
}

export interface PersonalInfo {
    patientId: string;
    patientName: string;
    age: number;
    gender: string;
    contactNumber: string;
    address: string;
}

export interface MedicalInfo {
    diagnosis: string;
    doctorName: string;
    symptoms: string;
    treatmentPlan: string;
    medications: string;
}

export interface BillingInfo {
    totalAmount: number;
    insuranceProvider: string;
    paymentStatus: string;
    billingDate: string;
}

export interface MedicalRecordRequest {
    personal: PersonalInfo;
    medical: MedicalInfo;
    billing: BillingInfo;
}

export interface TamperRequest {
    field: string;
    newValue: string;
    userRole: string;
}

export const api = {
    login: async (username: string, password: string) => {
        const response = await axios.post(`${API_BASE_URL}/auth/login`, { username, password });
        // Update axios header with new token
        axios.defaults.headers.common['Authorization'] = `Bearer ${response.data.token}`;
        return response.data;
    },

    getCurrentUser: async (token?: string) => {
        if (token) {
            axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        }
        const response = await axios.get(`${API_BASE_URL}/auth/me`);
        return response.data;
    },

    getRecords: async (): Promise<MedicalRecord[]> => {
        const response = await axios.get(`${API_BASE_URL}/records`);
        return response.data;
    },

    addRecord: async (record: MedicalRecordRequest): Promise<MedicalRecord> => {
        const response = await axios.post(`${API_BASE_URL}/records`, record);
        return response.data;
    },

    validateBlockchain: async (): Promise<{ status: string; invalidBlockIds: string[] }> => {
        const response = await axios.get(`${API_BASE_URL}/blockchain/validate`);
        return response.data;
    },

    simulateTamper: async (recordId: string, data: TamperRequest): Promise<any> => {
        const response = await axios.put(`${API_BASE_URL}/simulate_tamper/${recordId}`, data);
        return response.data;
    },

    getLogs: async (): Promise<any[]> => {
        const response = await axios.get(`${API_BASE_URL}/logs`);
        return response.data;
    },

    verifyRecord: async (recordId: string): Promise<any> => {
        const response = await axios.get(`${API_BASE_URL}/records/${recordId}/verify`);
        return response.data;
    },

    getNotifications: async (): Promise<any[]> => {
        const response = await axios.get(`${API_BASE_URL}/notifications`);
        return response.data;
    },

    markNotificationRead: async (notificationId: string) => {
        const response = await axios.post(`${API_BASE_URL}/notifications/${notificationId}/read`);
        return response.data;
    }
    ,
    // Record history and version actions
    getRecordHistory: async (recordId: string) => {
        const response = await axios.get(`${API_BASE_URL}/records/${recordId}/history`);
        return response.data;
    },
    approveVersion: async (recordId: string, versionId: string) => {
        const response = await axios.post(`${API_BASE_URL}/records/${recordId}/versions/${versionId}/approve`);
        return response.data;
    },
    declineVersion: async (recordId: string, versionId: string) => {
        const response = await axios.post(`${API_BASE_URL}/records/${recordId}/versions/${versionId}/decline`);
        return response.data;
    }
};
