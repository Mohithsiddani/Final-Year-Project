from python_backend.database import Database
from python_backend.blockchain import Blockchain
import json
import hashlib

print("Running Deep Debug Verification...")
db = Database()
bc = Blockchain(db)
records = db.get_all_records()

for i, record in enumerate(records):
    print(f"\n--- Checking Record {record['id']} ---")
    
    # 1. Recreate Data String (Exact Logic)
    data_to_hash = json.dumps({
        "personal": {
            "patientId": str(record.get("patientId")) if record.get("patientId") is not None else "",
            "patientName": str(record.get("patientName")) if record.get("patientName") is not None else "",
            "age": int(float(record.get("age"))) if record.get("age") is not None else 0,
            "gender": str(record.get("gender")) if record.get("gender") is not None else "",
            "contactNumber": str(record.get("contactNumber")) if record.get("contactNumber") is not None else "",
            "address": str(record.get("address")) if record.get("address") is not None else "",
        },
        "medical": {
            "diagnosis": str(record.get("diagnosis")) if record.get("diagnosis") is not None else "",
            "doctorName": str(record.get("doctorName")) if record.get("doctorName") is not None else "",
            "symptoms": str(record.get("symptoms")) if record.get("symptoms") is not None else "",
            "treatmentPlan": str(record.get("treatmentPlan")) if record.get("treatmentPlan") is not None else "",
            "medications": str(record.get("medications")) if record.get("medications") is not None else "",
        },
        "billing": {
            "totalAmount": float(record.get("totalAmount")) if record.get("totalAmount") is not None else 0.0,
            "insuranceProvider": str(record.get("insuranceProvider")) if record.get("insuranceProvider") is not None else "",
            "paymentStatus": str(record.get("paymentStatus")) if record.get("paymentStatus") is not None else "",
            "billingDate": str(record.get("billingDate")) if record.get("billingDate") is not None else "",
        }
    }, sort_keys=True)
    
    # 2. Compute SHA-256
    computed_sha256 = hashlib.sha256(data_to_hash.encode()).hexdigest()
    stored_sha256 = record["sha256Hash"]
    
    if computed_sha256 == stored_sha256:
        print("SHA-256: MATCH ✅")
    else:
        print("SHA-256: MISMATCH ❌")
        print(f"  Stored:   {stored_sha256}")
        print(f"  Computed: {computed_sha256}")
        print(f"  Data Used: {data_to_hash}")

    # 3. Compute Quantum Hash
    # Note: re-instantiating engine to ensure fresh state if needed, but using existing instance
    computed_quantum = bc.quantum_engine.generate_hash(data_to_hash)
    stored_quantum = record["quantumHash"]
    
    if computed_quantum == stored_quantum:
         print("Quantum: MATCH ✅")
    else:
         print("Quantum: MISMATCH ❌")
         print(f"  Stored:   {stored_quantum}")
         print(f"  Computed: {computed_quantum}")
         # Run it again to check stability
         computed_quantum_2 = bc.quantum_engine.generate_hash(data_to_hash)
         print(f"  Re-run:   {computed_quantum_2}")
         if computed_quantum != computed_quantum_2:
             print("  ⚠️ QUANTUM ENGINE IS NON-DETERMINISTIC ⚠️")

print("\nDebug Complete.")
